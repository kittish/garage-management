
<?php 
	
      error_reporting(E_ALL ^ E_NOTICE);
      error_reporting(E_ALL ^ E_DEPRECATED);
      
?><!DOCTYPE HTML>
<?php


// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'appointment';
 
if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

?>
<?php 

	$base_url = (isset($_SERVER['HTTPS'])?'https:':'http:').'//' . $_SERVER['HTTP_HOST'] . substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], "/") + 1);

?>
<!DOCTYPE html>

<head>
     <meta charset='utf-8' />
	<title>CDD Service</title>
        <!link href='css/fullcalendar.css' rel='stylesheet' />
	<link href='css1/fullcalendar.print.css' rel='stylesheet' media='print' />
	<meta name="description" content="website description" />
	<meta name="keywords" content="website keywords, website keywords" />
	<meta http-equiv="content-type" content="text/html; charset=windows-1252" />
	<!link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
        
         <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />
	
        
	<title>Appointment Calendar</title>
        
        <link rel="stylesheet" href="css/fullcalendar.css" />
        <link rel="stylesheet" href="css/fullcalendar.min.css" />
        <link rel="stylesheet" href="css/bootstrap.css" />
        
        <script src="js/jquery.min.js"></script>
        <script>src="js/jquery-1.3.2.min.js"</script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/moment.min.js"></script>
        <script src="js/fullcalendar.min.js"></script>
        
        <script src="js/moment.min.js"></script>
  
      
        <script src="bootstrap/js/bootstrap.js"></script>
        <script src="bootstrap/css/bootstrap.css"></script>
      
  <!  date time picker>
  
        
  <script src="/bootstrap/js/jquery.min_1.js"></script>
 <script src="bootstrap//moment.min.js"></script>
<script src="bootstrap-datetimepicker-master/js/bootstrap.min.js"></script>
<script src="bootstrap-datetimepicker-master/js/locales//bootstrap-datetimepicker.js"></script>
<link rel="stylesheet" href="bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min_1.css">

<script>   
        
   var base_url = "<?php echo $base_url; ?>";
	$(document).ready(function() {
		
		var calendar = $('#calendar').fullCalendar({
			header: {
				left 	: 'prev,next today',
				center 	: 'title',
				right 	: 'month,agendaWeek,agendaDay'
                                
                                
                                
                               
			},
                        
                    
                        
                        allDayDefault: false,
			//defaultDate 	: '2018-01-12',
			editable 	: true,
			eventLimit 	: true, // allow "more" link when too many events
                         events 	: base_url +'events.php',
			 
			selectable 	: true,
                       selectHelper 	: true,
		 	editable 	: true,
                         
                         
                   
                         
                         
              
           select: function(start, end, allDay) {
				
				$( "#add-appointment #start-date" ).val($.fullCalendar.formatDate(start, "yyyy-MM-dd HH:mm:ss"));
				$( "#add-appointment #end-date" ).val($.fullCalendar.formatDate(end, "yyyy-MM-dd HH:mm:ss"));
				$( "#add-appointment #all-day" ).val(allDay);
                                $( "#add-appointment #all-day" ).val(allDay);
				
				$( "#add-appointment" ).dialog();
                                
                            
	            
             	calendar.fullCalendar('unselect');
         	},	 
                
                
             eventRender: function(event, element)
			{ 
                            
              element.find('.fc-event-title').append("<br/>" + event.id); 
            }, 
                
			 
         	eventDrop : function(event) {
         		start 	= $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
             	   	end= $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss");
                        var title = event.title;
                        var id = event.id;
				console.log(event);
				console.log(end);
         		$.ajax({
             		url 	: base_url + 'update_events.php',
              		data  	:   'title='+ title+'&start='+ start +'&end='+ end +'&id='+id,
                         type 	: "POST",
              		success : function() {
                            alert("id eventDrop: "+ id);
                            alert("title eventDrop: " + title);
                            alert("start eventDrop: " + start);
                            alert("end eventDrop: " + end);
                                
                                calendar.fullCalendar('refetchEvents');
              			alert("Event updated");
                   
                   	}
                        
                        
              	});
          	},
			  
          	eventResize: function(event) {
              	start 	= $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
              	end 	= $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss");
                 var title = event.title;
                    var id = event.id;
				console.log(start);
				console.log(end);
          		$.ajax({
					url 	: base_url + 'update_events.php',
					data  	: 'title='+ title+'&start='+ start +'&end='+ end +'&id='+ id,
					type 	: "POST",
					success : function(json) {
                                            
                            alert("id eventResize: "+ id);
                            alert("title eventResize : " + title);
                            alert("start eventResize: " + start);
                            alert("end eventResize: " + end);
                            
			    alert("Event resize updated");
                         calendar.fullCalendar('refetchEvents');
					}
                });
            },
			  
          	eventClick: function(calEvent, jsEvent, view) {
          		$currentEvent = $(this);
			    if (confirm("Do you want to delete this event?") == true) {
			        $.ajax({
						url 		: base_url + 'delete_events.php',
						data 		: 'app_id='+ calEvent.id ,
						type 		: "POST",
						success 	: function(json) {
							$currentEvent.remove();
							alert("Event deleted");
						}
	                });
			    }
		    }
		});
	});
	</script>
        
        
        <script>
        
        function validateForm() 
 {
    var x = document.forms["appfrm"]["client_id"].value;
    if (isNaN(x))
    {
        alert("Name must be filled out");
        return false;
    }
  }
        
        </script>
  
  
  

  
</head>

	<body>
		<div id="main">
			<?php include_once('includes/header.php'); ?>
	    	<div id="site_content">
		      	<div class="sidebar">
	                <?php include_once('includes/sidebar.php'); ?>
	            </div>
	            <div class="pageContent">
	                <h2>Appointment Form</h2>
	           
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
    <li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
    <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
    <li><a data-toggle="tab" href="#menu3">Menu 3</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3>HOME</h3>
       <div id="calendar"> </div>
       
       
       
       
       
    </div>
    <div id="menu2" class="tab-pane fade">
      <h3>Team A</h3>
      <div>

        </div>
        
    </div>
    <div id="menu1" class="tab-pane fade">
        
      <h3>Team B</h3>
  
      <div>  
      </div>
      
    </div>
    <div id="menu3" class="tab-pane fade">
        <h3>Team C</h3>
      
    </div>
  </div>
</div>
	            </div>

			</div>
		</div>
		<div class="addAppointmentFOrmWrap" id="add-appointment" title="Add a new appointment">
            
                    
                    
                    
                    
                    
                    
		</div>
	    <?php include_once('includes/footer.php'); ?>
		
		<?php if(!empty($_GET) && !empty($_GET['t'])) : ?>
			<script>
				alert("<?php echo ($_GET['t'] == 1) ? 'Event saved succesfully' : 'Save failed';?>");
			</script>
		<?php endif; ?>
	</body>
</html>
