﻿<?php
// Values received via ajax



/*if(isset($_POST['btnsave2']))
    
{
$client_id = $_POST['client_id'];
$veh_num = $_POST['veh_num'];
$service_req = $_POST['service_req'];
$infor = $_POST['infor'];
$start_date=$_POST['start-date'];

// connection to the database
try       {
           $bdd = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');
          }
    catch(Exception $e) 
        {
           exit('Unable to connect to database.');
        }

// insert the records
//$sql = "INSERT INTO app_tbl (app_id,client_id,date_app, veh_num,service_req, start_date,end_date,infor,allDay)VALUES ('','".$client_id."',CURRENT_TIMESTAMP, '".$veh_num."','".$service_req."','".$start_date."', '','".$infor."','true')";
 $sql="INSERT INTO app_tbl (app_id)VALUES('')";



//$sql.="insert into billing_tbl (app_id) values($row)";

$q = $bdd->prepare($sql);




$s[]=$q->execute(array(
    ':app_id'=>'',
    ':client_id'=>$client_id,
    ':date_app'=>'CURRENT_TIMESTAMP',
    ':veh_num'=>$veh_num, 
    ':service_req'=>$service_req, 
    ':start_date'=>$start_date,
    ':end_date'=>'',
    ':infor'=>$infor
 
     ));

       print_r($result);
 

}

*/



if(isset($_POST['btnsave2']))
    
{
$client_id = $_POST['client_id'];
$veh_num = $_POST['veh_num'];
$service_req = $_POST['service_req'];
$infor = $_POST['infor'];
$start_date=$_POST['start-date'];


try {
    $conn = new PDO("mysql:host=localhost;dbname=garage_dob", 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
 
    
    
  $sql = "INSERT INTO app_tbl (app_id,client_id,date_app, veh_num,service_req, start_date,end_date,infor,allDay)VALUES ('','".$client_id."',CURRENT_TIMESTAMP, '".$veh_num."','".$service_req."','".$start_date."', '','".$infor."','true')";
    // use exec() because no results are returned
    
    $conn->exec($sql);
   /* $last_id = $conn->lastInsertId();
    
    
   echo "New record created successfully. Last inserted ID is: " . $last_id;
    $sql2="INSERT INTO billing_tbl(app_id) VALUES($last_id)";
    $conn->exec($sql2);
   $sql3="insert into depatch_tbl(app_id)values($last_id)";
   
    $conn->exec($sql3);
    
    $sql4="INSERT INTO main_veh_tbl(app_id) VALUES($last_id)";
     $conn->exec($sql4);
   */
    
         }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
    
  
    
}
?>