    <?php
include_once 'dbconfig.php';

 $txtBapp_id = "";
  $txtBveh_num="";
if (isset($_POST['btnSchapp_id']))
   {
    
   
   $txtBapp_id = $_POST['txtBapp_id'];
   $txtBveh_num=$_POST['txtBveh_num'];
  /*  $txtinvoice = $_POST['txtinvoice'];
    $txtBdate = $_POST['txtBdate'];
    $txtBclientnme = $_POST['txtBclientnme'];
    $txtBapp_id = $_POST['txtBapp_id'];
   
    $txtBamt_pay=$_POST['txtBamt_pay'];
    $txtBtotal=$_POST['txtBtotal'];
    $txtB_balance_due=$_POST['txtB_balance_due'];*/

try {

                     
                    $r1 = $DB_con->query("SELECT * FROM app_tbl WHERE app_id = ".$DB_con->quote($txtBapp_id));
                    $r1->execute();
                    $result1 = $r1->setFetchMode(PDO::FETCH_ASSOC);
                    
                    print_r($result1); 
    
   
         if($result1> 0)
                 { 
      
                   foreach($r1 as $row)
     
                       
                    // $invoice = $row['txtinvoice'];
                    // $Bdate = $row['txtBdate'];
                  // ':txtBapp_id' = $row['$txtBapp_id'];
                   //$txtBclientnme = $row['txtBclientnme'];
                    
                $txtveh_num = $row['veh_num'];
    
                               
            
             
	        }
   
    
         }
           catch(PDOException $e)
    {
    echo $result . "<br>" . $e->getMessage();
    }
    
    
   }

?>