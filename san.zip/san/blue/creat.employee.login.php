<!DOCTYPE HTML>

<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'creat.employee.login';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?> 
<?php
if(isset($_POST['btn-signup']))
{
	$unamertxt = trim($_POST['txt_unamer']);
	
	$upassrtxt = trim($_POST['txt_passwordr']);	
	
	if($unamertxt=="")	
            {
		$error[] = "provide username !";	
	    }
	
	else if($upassrtxt=="")
            {
		$error[] = "provide password !";
	    }
	else if(strlen($upassrtxt) < 4)
            {
		$error[] = "Password must be atleast 4 characters";	
	    }
	else
	{    
		try
		{
			$stmt = $DB_con->prepare("SELECT uname FROM login_tbl WHERE uname=:unamertxt");
                        
                       
			$stmt->execute(array(':unamertxt'=>$unamertxt));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
			echo " selection in database for entry in validation";
			if($row['uname']==$unamertxt)
                        { 
				$error[] = "sorry username already taken !";
			}
			
			else
			{
				if($user->register($unamertxt,$upassrtxt))
                                 
					
					$user->redirect('sign-up.php?joined');
				
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}

?>

<html>

<head>
  <title>CDD Service</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
</head>

<body>
    <div id="main">
        <?php include_once('includes/header.php'); ?>

        <div id="site_content">
            <div class="sidebar">
                <?php include_once('includes/sidebar.php'); ?>
            </div>
            <div class="pageContent">
                <h2>Create Employee Login</h2>
                <form method="post" id="createEmployeeLoginForm">
            <?php
            if(isset($error))
            {
                foreach($error as $error)
                {
                     ?>
                     <div class="alert alert-danger">
                        <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?>
                     </div>
                     <?php
                }
            }
            else if(isset($_GET['joined']))
            {
                 ?>
                 <div class="alert alert-info">
                      <i class="glyphicon glyphicon-log-in"></i> &nbsp; Successfully registered <a href='index.php'>login</a> here
                 </div>
                 <?php
            }
                        
                       
            ?>
            
           
            <div class="">
            <input type="text" class="form-control" name="txt_unamer" placeholder="Enter Username" value="<?php if(isset($error)){echo $unamertxt;}?>" />
            </div>
            
            
            <div class="">
                <input type="password" class="form-control" name="txt_passwordr" placeholder="Enter Password" value ="<?php if(isset($error)){echo $upassrtxt;} ?>"/>
            </div>
           
           
            <div class="">
                
                <input type="submit" name="btn-signup"  value="Create Login" />
            </div>
            
            </div>
            <br />
           
        </form>
            </div>           
        </div>
    </div>
    <div id="footer">
      Copyright &copy; CDD Garage | <a href="http://validator.w3.org/check?uri=referer">Lees Street</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">Curepipe</a> | <a href="http://www.html5webtemplates.co.uk"></a>
    </div>
  </div>
</body>
</html>
