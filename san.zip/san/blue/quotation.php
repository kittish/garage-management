<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'home';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?>
<html>
    <head>
        <title>CDD Service</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="website description" />
        <meta name="keywords" content="website keywords, website keywords" />
        <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
        <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />
        
        
        <link rel="stylesheet" href="style/style2.css">
		
		<script src="style/script.js"></script>
    </head>

    <body>
        <div id="main">
            <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                  
			<header>
			<h1>Receipt</h1>
			
		
		</header>
		<article>
			<h1>Recipient</h1>
			<address contenteditable>
				
				<p>CDD Garage</p>
				<p>Rue Lees, Curepipe<br> (230)6704747</p>
				
			
			</address>
			<table class="meta">
				<tr>
					<th><span contenteditable>Invoice #</span></th>
					<td><span contenteditable>101138</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable>January 1, 2012</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Due</span></th>
					<td><span id="prefix" contenteditable>$</span><span>600.00</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span contenteditable>Item</span></th>
						<th><span contenteditable>Description</span></th>
						<th><span contenteditable>Rate</span></th>
						<th><span contenteditable>Quantity</span></th>
						<th><span contenteditable>Price</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><span contenteditable>Front End Consultation</span></td>
						<td><span contenteditable>Experience Review</span></td>
						<td><span data-prefix>$</span><span contenteditable>150.00</span></td>
						<td><span contenteditable>4</span></td>
						<td><span data-prefix>$</span><span>600.00</span></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Paid</span></th>
					<td><span data-prefix>$</span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Balance Due</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span contenteditable>Additional Notes</span></h1>
			<div contenteditable>
				<p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
			</div>
		</aside>		
       
  
            </div>
        </div>

        <?php include_once('includes/footer.php'); ?>
    </body>
</html>
