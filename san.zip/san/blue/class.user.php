<?php
class USER
{
	private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
	
	public function register($unamertxt,$upassrtxt)
	{
		try
		{
                   
			$new_password = password_hash($upassrtxt, PASSWORD_DEFAULT);
			
			$stmt = $this->db->prepare("INSERT INTO login_tbl(uname,pwd) VALUES(:unamertxt,:upassrtxt)");
												  
			$stmt->bindparam(":unamertxt", $unamertxt);
			
                        
            $stmt->bindparam(":upassrtxt", $new_password);	
			 echo "insert registration";	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function login($unametxt,$upasstxt)
	{
		try
		{
			  
			$stmt = $this->db->prepare("SELECT * FROM login_tbl WHERE uname=:unametxt  LIMIT 1");
			$stmt->execute(array(':unametxt'=>$unametxt));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
                        
                       
			if($stmt->rowCount() > 0)
			{ 
		         if($userRow!=0)
                           
				//if(password_verify($upasstxt, $userRow['pwd']))
				{    
                                 
					$_SESSION['user_session'] = $userRow['uname']; 
                                    
					return true;
                                        
 
                                        
				}
				else
				{echo"no t work";
					return false;
					
				}
			} 
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function is_loggedin()
	{
		if(isset($_SESSION['user_session']))
		{
			return true;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function logout()
	{
		session_destroy();
		unset($_SESSION['user_session']);
		return true;
	}
        
        
        public function clientval()
        {
			
         
				 
				
            
        }
        
       
	
		 
  
  }
