<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'reg_client';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?>
<html>

<head>
    <title>CDD Service</title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="website description" />
    <meta name="keywords" content="website keywords, website keywords" />
    <meta http-equiv="content-type" content="text/html; charset=windows-1252" />

    <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />

</head>

<body>
    <div id="main">
        <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                   <?php include_once 'includes/insert_new_client.php';   ?>
 
        <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
         
           <table align="center" border="4" cellspacing="5" cellpadding="15" width="100%">
                
                <tbody>
                    
                    
                    <tr>
                    
                        <td colspan="2" class="formValue"  align="center"><font size="18">Client Registration Form</font></td> 
                    </tr>
                               
                    <tr>
                        <td width="30%"   align="right">Client ID:</td>
                         
                         
                         <td width="55%"class="formValue" align="left"><input align="center" type="text" placeholder="Client ID " id="client_id" name="txtclient_id" value=<?php if(!(empty($client_id))){echo $client_id;}else {echo "";}?> > 
                                                     <span> <input type="submit" value="Search By ID" name="btnsearch2" class="submit"></span></td>
                       
                    </tr>
                    
                    <tr>
                    
                       <td colspan="2" align="center"></td> 
                    </tr>
                              
                    
                     <tr>
                        <td width="30%" class="formValue"  align="right">Ownership :</td>
                        <td width="70%" align="left">
						
				<select name="ddlowner">
                                 <option   > <?php {echo"  ";}?></option>
                                <option <?php if($owner=="Govt") {echo"selected";} else {echo"";} ?> > Govt</option>
                                <option <?php if($owner=="Private") {echo"selected";} else {echo"";} ?>>Private </option>
                                <option <?php if($owner=="Company") {echo"selected";} else {echo"";} ?>>Company</option>
                        </select><span><?php  echo $err1;  ?></span></td>
                                
                    </tr>
                    
                    <tr>
                         <td width="30%"  class="formValue" align="right">Surname:</td>
                        
                         
                         <td width="70%" class="formValue" align="left"><input align="center" type="text"  id="snamec" name="txtsnamec" value=<?php if (!(empty($snamec))) {echo $snamec;}else {echo "";}  ?> ><span><?php  echo $err2;  ?></span></input></td>
                    </tr>
                    <tr>
                         <td width="30%"   align="right">Other Name:</td>
                        <td width="70%" align="left"><input type="text" placeholder="Enter Last Name" id="onamec" name="txtonamec" value=<?php if (!(empty($onamec))){echo $onamec;} else {echo"";}  ?>><span><?php  echo $err3;  ?></span></input>
                </td>
                    </tr>
                   
                    <tr>
                         <td width="30%"   align="right">D.O.B</td>
                         <td width="70%" align="left"><input type="text" placeholder="YY-MM-DD" id="dob" name="txtdobc" value=<?php echo $dobc;  ?> ><span><?php  echo $err4;  ?></span></input>
                                                            </tr>
                     <tr>
                         <td width="30%"   align="right">Gender:</td>
                         <td width="70%" align="left">
						 
						 <select name="genderc" class="formValue">
                                <option> <?php {echo "  ";}?></option>
                                <option <?php if($genderc=="Male") {echo"selected";} else {echo"";} ?> > Male</option>
                                <option <?php if($genderc=="Female") {echo"selected";} else {echo"";} ?>>Female </option>
                               
                         </select><span><?php  echo $err5;  ?></span></td>
                             
						   
                            </td>
                    </tr>
                    
                    <tr>
                        <td width="30%"  align="right">Email :</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Email" id="email" name="txtemail" value=<?php echo "$email";  ?> ><span><?php  echo $err6;  ?></span></input> 
                </td>
                    </tr>
                    <tr>
                        <td width="30%"   align="right">Contact :</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Contact Number" id="contact" name="txtcontact_num"value=<?php echo $contact_num;  ?>><span><?php  echo $err7;  ?></span></input></td>
                    </tr>
                   
                    
                    <tr>
                         <td width="30%"   align="left">Date Of Registration :</td>
                         <td width="70%" align="left"><input type="text"  placeholder=":YY-MM-DD" id="dor" name="txtdor" value=<?php echo $dor;  ?>><span><?php  echo $err8;  ?></span></input></td>
                    </tr>
                    <tr
                        
                        <tr>
                         <td width="30%"   align="left">Contract ID :</td>
                         <td width="70%" align="left"><input type="text"  placeholder="Enter Contract ID" id="dor" name="txtcontract_id" value=<?php echo $contract_id;  ?>><span><?php  echo $err9;  ?></span></input></td>
                        </tr>
                    <tr>
                        
                        
                        <td colspan="2" align="center"><input type="Submit" value="Save" name="btnsave2" class="submit"> 
                                               
                                            <input type="submit" value="reset" name="btnreset2" class="submit">
                                           
                             </td>
                    </tr>
                    <tr>
                    
                        <td colspan="2" align="center"><input type="submit" value="Edit" name="btnedit" class="submit"> 
                                &nbsp; &nbsp;<input type="Submit" value="Update" name="btnupdate2" class="submit">
                                    &nbsp; &nbsp;<input type="Submit" value="Delete" name="btndelete2" class="submit"></td>
                    </tr>
                    
                </tbody>
            </table>
        </form>
                </div>           
            </div>
		
		
	
    <?php include_once('includes/footer.php');?>
  </div>
</body>
</html>
