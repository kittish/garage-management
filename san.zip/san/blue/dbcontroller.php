<?php
error_reporting(E_ALL ^ E_NOTICE);
error_reporting(E_ALL ^ E_DEPRECATED);
class DBController {
	private $host = "localhost";
	private $user = "root";
	private $password = "";
	private $database = "garage_dob";
	private $db;
	
	
	function __construct() {
		
		
		$conn = $this->connectDB();
		if(!empty($conn)) {
			$this->selectDB($conn);
		}
	}
	
	function connectDB() 
	{  
		
		$conn = mysql_connect($this->host,$this->user,$this->password);
		return $conn;
	}
	
	function selectDB($conn) 
	{
		
		
		mysql_select_db($this->database,$conn);
	}
	
	function runQuery($query)
	{
		$result = mysql_query($query) ;
		
		if(!empty($result)) {
			
			while($row=mysql_fetch_assoc($result)) 

				{
				$resultset[] = $row;
			
				}	 
				
			if(!empty($resultset)){
				
				return $resultset;
			}
		}
		return null;
	}
		
		
	
	function numRows($query) {
		$result  = mysql_query($query);
		$rowcount = mysql_num_rows($result);
		return $rowcount;	
	}
}
?>