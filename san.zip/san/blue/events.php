
 <?php
 
// List of events
 $json = array();

 

 // connection to the database
 try 
 {
 $bdd = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');
 
 
 // Query that retrieves events
  $requete = "SELECT * FROM app_tbl ORDER BY app_id";
 } catch(Exception $e) 
 {
  exit('Unable to connect to database.');
 }
 $data[] = array();

 // Execute the query
 $resultat = $bdd->query($requete) or die(print_r($bdd->errorInfo()));

 
 foreach($resultat as $row)  {
     
     $data[]=array(
         
    
     
     'title'   =>$row["service_req"],
    
     'start'   => $row["start_date"],
     'end'   => $row["end_date"],
 
     'id'   =>$row["app_id"]
         
         
         
         
     );
     
   //echo $output['app_id'] . " " . $output['veh_num'] . " ".  $output['service_req'] ."<br />";
}

 
 
 
 // sending the encoded result to success page
 echo json_encode($data);
 // 
 
 
 

?>



 

