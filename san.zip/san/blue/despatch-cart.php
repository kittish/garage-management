<?php
	session_start();
	// connexion à la base de données
	try {
		$bdd = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');

	} catch(Exception $e) {
		exit('Impossible de se connecter à la base de données.');
	}

	//20.03.18
	//Changed the fields in the db as below, start, end. 
	        
	foreach($_POST['product'] as $product) {
		$sql 	= "INSERT INTO depatch_tbl (`app_id`, `veh_num`, `prod_id`, `quantity_rec`) 
			VALUES (?,?,?,?);";
		
		
                 $q 		= $bdd->prepare($sql);
		
		$q->execute(
			array($_POST['app_id'], $_POST['veh_num'], $product['id'], $product['quantity'])			
		);	
                print_r(array($_POST['app_id'],$_POST['veh_num'],$product['id'],$product['quantity']));
               
             
               
            
                 $qu=$product['quantity'];
                 $qui=$product['id'];
               
                $sqld= "update store_tbl SET quantity = quantity-$qu where prod_id=".$qui;	
                $sq=$bdd->prepare($sqld);
                $sq->execute();  
               
                
          
                
                 }  
       
   
       
        
	$_SESSION["cart_item"] = null;
	unset($_SESSION["cart_item"]);
	
	//header('location:despatch.php');
	