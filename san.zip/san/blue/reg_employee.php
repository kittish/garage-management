<!DOCTYPE HTML>

<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'reg_employee';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?> 


<html>

<head>
  <title>CDD Service</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
  
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css"  />
  
</head>

<body>
  <div id="main">
    <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                    <h2>Employee Registration Form</h2>
       <?php include_once 'includes/insert-new-employee.php';   ?>    
      <?php
          if(isset($_post['btnreset']))
              
              
        
    { $id="";
              
    $msg1="";
	$msg2="";
     $emp_id="";
     $sname="";
	 $oname="";
     $dob="";
    $gender="";
     $basic_sal = "";
     $o_time_rate = "";
        
      $doe ="";
      $str="";
       $check1=null;
       $check2=null;
       $check3=null;
       $check4=null;
    }
    
    ?>
   
 
        <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
         
            <table align="center" border="4" cellspacing="5" cellpadding="15" width="100%">
                
                <tbody>
                    <tr>
                        <td width="30%"   align="right">Employee ID:</td>
                         
                         
                         <td width="55%" align="left"><input align="center" type="text" placeholder="Auto Generated" id="emp_id" name="txtemp_id" value=<?php if(!(empty($emp_id))){echo $emp_id;}else {echo "";}?> > 
                                                     <span> <input type="submit" value="Search By ID" name="btnsearch1" class="submit"> </span><span><?php //if(!empty($msg1)) {echo "";} else {echo $msg1;}   ?></span><span><?php if(!(empty($id))){echo $id;}else {echo "";}?></span></td>
                       
                    </tr>  
                    <tr>
                         <td width="30%"  align="right">Surname:</td>
                        
                         
                         <td width="70%" align="left"><input align="center"  type="text"  placeholder="Enter Surname"  id="sname" name="txtsname" value=<?php if (!empty($sname)) {echo $sname;}else {echo "";}  ?> ><span > <a color="red" ><?php echo $err1; ?></a></span></input></td>
                    </tr>
                    <tr>
                         <td width="30%"   align="right">Other Name:</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Your Last Name" id="oname" name="txtoname" value=<?php if (!empty($oname)){echo $oname;} else {echo"";}?>><span> <?php echo $err2; ?></span></input>
                </td>
                    </tr>
                    <tr>
                        <td width="30%"   align="right">Job Tittle:</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Job Tittle" id="jobtittle" name="txtjobtittle" value=<?php if(!empty($jobtittle)){echo $jobtittle;}else {echo "";}  ?> ><span color="red" ><?php echo $err3; ?></span></td>
                    </tr>
                    <tr>
                         <td width="30%"   align="right">D.O.B</td>
                         <td width="70%" align="left"><input type="text"  placeholder="YY-MM-DD" id="dob" name="txtdob" value=<?php  if(!empty($dob)){echo $dob;} else {echo "";}  ?>><span color="red" ><?php echo $err4; ?></span></td>
                    </tr>
                    <tr>
                        <td width="30%"  align="right">Basic Salary (Rs):</td>
                        <td width="70%" align="left"><input type="text"   placeholder="Enter Basic Salary" id="basic_sal" name="txtbasic_sal" value=<?php   if(!empty($basic_sal)){echo $basic_sal;} else {echo "";}  ?>>  <span><?php echo $err5;?></span></input></td>
                
                    </tr>
                    <tr>
                        <td width="30%"   align="right">Over Time Rate/hr:</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Over Time Rate" id="o_time_rate" name="txto_time_rate"  value=<?php if(!empty($o_time_rate)) {echo $o_time_rate;} else {echo "";}  ?>>  <span><?php echo $err6; ?></span> </input></td>
                    </tr>
                        <tr>
                         <td width="30%"   align="right">Gender:</td>
                         <td width="70%" align="left">
						 
						 <select name="dllgender" >
                                <option> <?php echo "";?></option>
                                <option <?php if($gender=="Male") {echo"selected";} else {echo"";} ?> > Male</option>
                                <option <?php if($gender=="Female") {echo"selected";} else {echo"";} ?>>Female </option>
                               
                         </select><span><?php  echo $err7;  ?></span></td>
                             
						   
                            </td>
                    </tr>
                    <tr>
                         <td width="30%"   align="right">Qualification:</td>
                         <td width="70%" align="left">
                            <input type="checkbox" name="chkq[]" value="Vocational" <?php if(empty($strchkq)) {echo $check1;} else {echo $strchkq;} ?> ></input><span>Vocational</span>
                            <input type="checkbox" name="chkq[]" value="SC"<?php if(empty($strchkq)) {echo $check2;} else {echo $strchkq;} ?>></input><span>SC</span>
                            <input type="checkbox" name="chkq[]" value="HSC"<?php if(empty($strchkq)) {echo $check2;} else {echo $strchkq;} ?>  ><span>HSC</span>
                            <input type="checkbox" name="chkq[]" value="Degree"<?php if(empty($strchkq)) {echo $check3;} else {echo $strchkq;} ?>  ><span>Degree</span><span><?php echo $err8; ?></span></td>
                    </tr>
                    <tr>
                         <td width="30%"   align="left">Date Of Entry:</td>
                         <td width="70%" align="left"><input type="text"  placeholder="YY-MM-DD" id="doe" name="txtdoe" value=<?php if(!empty($doe)) echo $doe; else echo ""; ?>><span><?php echo $err9; ?></span></input></td>
                    </tr>
                    <tr>
                        
                        <td colspan="2" align="center"><input type="Submit" value="ADD" name="btnadd" class="submit"> 
                                               
                                            <input type="submit" value="reset" name="btnreset" class="submit">
                                           </td>
                             
                    </tr>
                    <tr>
                    
                        <td colspan="2" align="center"><input type="submit" value="Edit" name="btnedit" class="submit"> 
                                &nbsp; &nbsp;<input type="Submit" value="Update" name="btnupdate" class="submit">
                                    &nbsp; &nbsp;<input type="Submit" value="Delete" name="btndelete1" class="submit"></td>
                    </tr>
                    
                </tbody>
            </table>
        </form>
    </div>           
</div>
    <?php include_once('includes/footer.php'); ?>
</body>
</html>
