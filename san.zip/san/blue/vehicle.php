<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'vehicle';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?> <?php
         if(isset($_post['emp_id']))
        
    {$up="select * from emp_tbl where emp_id=".$_post['emp_id'];
 
     $rst=mysql_query($up);
    $fetched_row=  mysql_fetch_array($rst);}
     
     ?>

<html>

<head>
  <title>CDD Service</title>
  
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
 
 <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />

</head>

<body>
  <div id="main">
            <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">

       
     <?php
     
     
     $txtveh_num="";
     $txtmake="";
     $txtmodel="";
     $engcap="";
     $txtcolor="";
     $txtclient_id="";
     
     
       $err2="";
       $err1="";
       $err4="";
       $err5="";
       $err6="";
       $err7="";
       $err8="";
       $err3="";
    
      if(isset($_POST['btnsavev']))
       {
   
   
          
         
       $txtveh_num=trim($_POST['txtveh_num']);
           $txtmake=trim($_POST['txtmake']);
           $txtmodel = trim($_POST['txtmodel']);
           $txtengcap = trim($_POST['txtengcap']);
           $txtcolor = trim($_POST['txtcolor']);
           $txtclient_id = trim($_POST['txtclient_id']);
          
           
             if ($txtveh_num=="")
        
        {
        $err1="Insert Vehicle Number...";}
          
      
        
        else if ($txtmake=="")
        {
          $err2 =" please input Vehicle Make..";
          
        }
        
         else if ($txtmodel=="")
           
           {
             $err3=" Input Vehicle model....   ";
             
             
           }
           
          
        
        
           
           else if($txtengcap=="") 
           
           {
             $err4="Please Enter Vehicle Engine Capacity...";
           }
           else if ($txtcolor=="")
        {
          $err5 ="please input vehicle colour..";
          
        }
         else if ($txtclient_id="")
           
         
         {$err6 ="Please Enter Client ID ...";}      
         
        else
      
         try { 
  
          
         
              $stmt = $DB_con->prepare("INSERT INTO veh_tbl
              (veh_num,make,model,engine,color,client_id)
              VALUES('$txtveh_num','$txtmake','$txtmodel','$txtengcap','$txtcolor','$txtclient_id')");
        
        
        
    

              $stmt->bindparam(':$txtveh_num', $txtveh_num);
              $stmt->bindparam(':$txtmake', $txtmake);
              $stmt->bindparam(':$txtmodel', $txtmodel);
              $stmt->bindparam(':$txtengcap', $txtengcap);
              $stmt->bindparam(':$txtcolor', $txtcolor);       
              $stmt->bindparam(':$txtclient_id', $txtclient_id);
              
                        
             

                $stmt->execute(); 
      
              echo" execute command work vehicle";  
         
                return $stmt;
            
               //$User->redirect('reg_client.php');
                }
                    catch(PDOException $e)
               {
                echo $e->getMessage();
               }
   }
     if(isset($_POST['btnsearchv']))
          {        
             
             
             $txtveh_num =$_POST['txtveh_num'];
             
            
            
           try {

                   

                {
               
               
                                      
    $r = $DB_con->query("SELECT * FROM veh_tbl WHERE veh_num = ".$DB_con->quote($txtveh_num));
     
    $r->execute();
    $result = $r->setFetchMode(PDO::FETCH_ASSOC);
      
     } 
      
    
           foreach($r as $row)
     
               {
        
           $veh_num=$row['veh_num'];
           $txtmake=$row['make'];
           $txtmodel =$row['model'];  
           $txtengcap = $row['engine'];
           $txtcolor= $row['color'];
           $txtclient_id=$row['client_id'];
  
       
           }
              
           }
           catch(PDOException $e)
           {echo "Error occurs:". $e->getMessage();}
       
       
                      
          }  
                    
       if(isset($_POST['btnupdatev']))
      
    
       try
        { 
       
           $txtveh_num=trim($_POST['txtveh_num']);
           $txtmake=trim($_POST['txtmake']);
           $txtmodel = trim($_POST['txtmodel']);
           $txtengcap = trim($_POST['txtengcap']);
           $txtcolor = trim($_POST['txtcolor']);
           $txtclient_id = trim($_POST['txtclient_id']);
      
      $upd = "UPDATE veh_tbl SET  veh_num= '$txtveh_num', make='$txtmake',model='$txtmodel',engine='$txtengcap',color='$txtcolor',client_id='$txtclient_id' WHERE veh_num= $txtveh_num";


// $upd = " UPDATE `garage_dob`.`veh_tbl` SET `client_id` = '1' WHERE `veh_tbl`.`veh_num` = '1359'";




//  Prepare statement
    $stmtup = $DB_con->prepare($upd);

    // execute the query
    $stmtup->execute();
    
    
    }
 catch(PDOException $e)
    {//   
    echo $upd . "<br>" . $e->getMessage();
  

    }
         
    if(isset($_POST['btndeletev']))
        
    {   $txtveh_num= trim($_POST['txtveh_num']);
        
        try {
  
    // sql to delete a record
    $del = "DELETE FROM veh_tbl WHERE veh_num=$txtveh_num";

    // use exec() because no results are returned
    $DB_con->exec($del);
    echo "Record deleted successfully";
    }
       catch(PDOException $e)
    {
    echo $del . "<br>" . $e->getMessage();
    }


    }
            
     
      ?>

 
        <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
         
           <table align="center" border="4" cellspacing="5" cellpadding="15" width="100%">
                
                <tbody>
                    
                    
                    <tr>
                    
                        <td colspan="2"  align="center"><font size="18">Vehicle Form</font></td> 
                    </tr>
                               
                    <tr>
                        <td width="30%"   align="right">Vehicle Number:</td>
                         
                         
                         <td width="55%" align="left"><input align="center" type="text" placeholder="Insert Vechicle Number " id="veh_num" name="txtveh_num" value=<?php if(!(empty($txtveh_num))){echo $txtveh_num;}else {echo "";}?> > 
                                                     <span> <input type="submit" value="Search By ID" name="btnsearchv" class="submit"></span><span><?php echo $err1; ?></span></td>
                       
                    </tr>
                    
                    <tr>
                    
                       <td colspan="2" align="center"></td> 
                    </tr>
                              
                    
                     
                    
                    <tr>
                         <td width="30%"  align="right">Make</td>
                        
                         
                         <td width="70%" align="left"><input align="center" type="text" placeholder="Enter Vechicle Make"  id="make" name="txtmake" value=<?php if (!(empty($txtmake))) {echo $txtmake;}else {echo "";}  ?> ><span><?php  echo $err2;  ?></span></input></td>
                    </tr>
                    <tr>
                         <td width="30%"   align="right">Model :</td>
                        <td width="70%" align="left"><input type="text" placeholder="Enter Model Vehicle" id="model" name="txtmodel" value=<?php if (!(empty($txtmodel))){echo $txtmodel;} else {echo"";}  ?>><span><?php  echo $err3;  ?></span></input>
             </td>
                    </tr>
                  
                    <tr>
                         <td width="30%"   align="right">Engine Capacity:</td>
                         <td width="70%" align="left"><input type="text" placeholder="Enter Engine Capacity" id="engcap" name="txtengcap" value=<?php if (!(empty($txtengcap))){echo $txtengcap;} else {echo"";} ?>><span><?php  echo $err4;  ?></span></input></td>
                    </tr>
                     <tr>
                         <td width="30%"   align="right">Color</td>
                        
                         <td width="70%" align="left"><input type="text" placeholder="Enter Vehicle Color." id="color" name="txtcolor" value=<?php if (!(empty($txtcolor))){echo $txtcolor;} else {echo"";} ?>><span><?php  echo $err5;  ?></span></input></td>
                    </tr>
                    
                    
                    </tr>
                    <tr>
                        <td width="30%"   align="right">Client ID  :</td>
                        <td width="70%" align="left"><input type="text"  placeholder="Enter Client_id" id="txtclient_id" name="txtclient_id"value=<?php echo $txtclient_id;  ?>><span><?php  echo $err6;  ?></span></input></td>
                    </tr>
                   
                    
                   <tr>
                        
                        
                        <td colspan="2" align="center">&nbsp; &nbsp;&nbsp; &nbsp;<input type="Submit"  value="Save" name="btnsavev" class="submit"> 
                                               
                                                      &nbsp; &nbsp;&nbsp; &nbsp;<input type="submit" value="reset" name="btnresetv" class="submit">
                                           
                             </td>
                    </tr>
                    <tr>
                    
                        <td colspan="2" align="center">
                                    &nbsp; &nbsp;&nbsp; &nbsp;<input type="Submit" value="Update" name= "btnupdatev"class="submit">
                                    &nbsp; &nbsp;&nbsp; &nbsp;<input type="Submit" value="Delete" name="btndeletev" class="submit"></td>
                    </tr>
                    
                </tbody>
            </table>
        </form>
  

                </div>           
            </div>
        </div>

  <?php include_once('includes/footer.php'); ?>
</body>
</html>
