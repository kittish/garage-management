<!DOCTYPE html>
<style>
   .button {
       background-color: black; /* Green */
       border: none;
       color: white;
       padding: 2px 4px;
       text-align: center;
       text-decoration: none;
       display: inline-block;
       font-size: 12px;
       margin: 4px 2px;
       cursor: pointer;
   }

   .button5 {padding: 2px 10px;}/* Black */
</style>
<style>
    
    .button1 {
  background-color: 33B8FF; /* Green */
    border: 1;
    color: black;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
 }


.button2 {padding: 12px 40px;}
    </style>
    
    
   <?php
   include_once 'dbconfig.php';
   
   
   ?>
        
        
           
<?php
$txtBclient_id=$txtBtotall = $txtBdate_app = $txtBdate = $txtBapp_id = "";
$txtBclientnme = $txtBamt_pay = $txtB_balance_due = $txtinvoice = $txtBapp_id = $txtBveh_num = "";


error_reporting(E_ALL ^ E_NOTICE);
error_reporting(E_ALL ^ E_DEPRECATED);
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'home';

if (!$user->is_loggedin()) {
    $user->redirect('index.php');
}
//slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname" => $uname));
$userRow = $stmt->fetch(PDO::FETCH_ASSOC)
?>
        <title>CDD Service</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="website description" />
        <meta name="keywords" content="website keywords, website keywords" />
        <!meta http-equiv="content-type" content="text/html; charset=windows-1252" />
        <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />

        <script type='text/javascript' src='css/jquery.min.js'></script>
        
        <link rel="stylesheet" href="style/style2.css">

        <script src="style/script.js"></script>
    </head>
      <?php 
   //code to generate invoice 
$r5 = $DB_con->query("SELECT receipt_id  AS  LAST_INSERT_ID from billing_tbl");
  $r5->execute();
 $res=$r5->setFetchMode(PDO::FETCH_ASSOC);
  if($res>0){
 foreach($r5 as $out )
     
 {
    $last= $out['LAST_INSERT_ID'] +1;
     
 }
  }
  
  
  
  
  if(isset($_POST['btnBclear']))
      
  {
      $txtBclient_id=$txtBtotall = $txtBdate_app = $txtBapp_id = "";
$txtBclientnme = $txtBamt_pay = $txtB_balance_due = $txtinvoice = $txtBapp_id = $txtBveh_num = "";
  }
  ?>
      
    <script>
   function myFunction() {
    
          $('#Btotall').val('');
          $('#Bdate_app').val('');
          $('#Bclientsme').val('');
          $('#Bclientnme').val('');
          $('#Bamt_pay').val('');
          $('#B_balance_due').val('');
          $('#invoice ').val('');
          $('#Bveh_num').val('');
          $('#Bclient_id').val('');
          $('#Bdate').val('');
          $('#Binvoice').val('');
          
         
}
    </script>

    <body>
        <div id="main">
<?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
<?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">

                    <header>
                        <h1>Billing Form</h1>
                        <a href="billingreport.php"><button class="button1">Billing Report</button></a>
                   <?php
if (isset($_POST['btnBinvoice'])) {

   
  $txtBapp_id = $_POST['txtBapp_id'];
  $txtBveh_num=$_POST['txtBveh_num'];
  $txtBreceipt_id = $_POST['txtBreceipt_id'];
   $txtBdate = $_POST['txtBdate'];
   $txtBclientnme = $_POST['txtBclientnme'];
   $txtBclientsnme=$_POST['txtBclientsnme'];
   //$txtBapp_id = $_POST['txtBapp_id'];
   $txtBdate_app=$_POST['txtBdate_app'];
   $txtBamt_pay=$_POST['txtBamt_pay'];
   $txtBclient_id=$_POST['txtBclient_id'];
  

   $txtB_balance_due=$_POST['txtB_balance_due'];

    try {


        // $r1 = $DB_con->query("SELECT * FROM app_tbl WHERE app_id = ".$DB_con->quote($txtBapp_id));

        $r8 = $DB_con->query("SELECT billing_tbl.receipt_id,billing_tbl.chk_out_date,billing_tbl.total_pay,billing_tbl.amt_pay,
            billing_tbl.balance_due,billing_tbl.app_id,billing_tbl.client_id,veh_tbl.veh_num, app_tbl.date_app, client_tbl.snamec, client_tbl.onamec,depatch_tbl.prod_id 
FROM (((((
billing_tbl

INNER JOIN app_tbl ON billing_tbl.app_id = app_tbl.app_id
)
INNER JOIN client_tbl ON client_tbl.client_id = billing_tbl.client_id
)
INNER JOIN veh_tbl ON veh_tbl.client_id =client_tbl.client_id
)
INNER JOIN depatch_tbl ON depatch_tbl.app_id = app_tbl.app_id
)
INNER JOIN store_tbl ON store_tbl.prod_id = depatch_tbl.prod_id
)
WHERE billing_tbl.receipt_id=" . $DB_con->quote($txtBreceipt_id));
        $r8->execute();
        $result8 = $r8->setFetchMode(PDO::FETCH_ASSOC);

        //  print_r($result1); 


        if ($result8 > 0) {

            foreach ($r8 as $row) {

                $txtBreceipt_id = $row['receipt_id'];
                $txtBdate = $row['chk_out_date'];
                $txtBapp_id = $row['app_id'];
                $txtBclientnme = $row['onamec'];
                 $txtBclientsnme=$row['snamec'];
                $txtBveh_num = $row['veh_num'];

                $txtBdate_app=$row['date_app'];
                $txtBclient_id=$row['client_id'];
                $txtB_balance_due=$row['balance_due'];
                $txtBamt_pay=$row['amt_pay'];
            }
        }
    } catch (PDOException $e) {
        echo $result8 . "<br>" . $e->getMessage();
    }
}
?>
                        
                    
<?php
if (isset($_POST['btnSchapp_id'])) {

   
  $txtBapp_id = $_POST['txtBapp_id'];
  $txtBveh_num=$_POST['txtBveh_num'];
  $txtBreceipt_id = $_POST['txtBreceipt_id'];
   $txtBdate = $_POST['txtBdate'];
   $txtBclientnme = $_POST['txtBclientnme'];
   $txtBclientsnme=$_POST['txtBclientsnme'];
   //$txtBapp_id = $_POST['txtBapp_id'];
   $txtBdate_app=$_POST['txtBdate_app'];
   $txtBamt_pay=$_POST['txtBamt_pay'];
   $txtBclient_id=$_POST['txtBclient_id'];
  

   $txtB_balance_due=$_POST['txtB_balance_due'];

    try {


        // $r1 = $DB_con->query("SELECT * FROM app_tbl WHERE app_id = ".$DB_con->quote($txtBapp_id));

        $r1 = $DB_con->query("SELECT app_tbl.app_id, veh_tbl.veh_num, app_tbl.date_app, client_tbl.snamec, client_tbl.onamec,client_tbl.client_id
FROM ((

app_tbl

INNER JOIN client_tbl ON app_tbl.client_id = client_tbl.client_id
)
INNER JOIN veh_tbl ON app_tbl.veh_num = veh_tbl.veh_num

)
WHERE app_tbl.app_id=" . $DB_con->quote($txtBapp_id));
        $r1->execute();
        $result1 = $r1->setFetchMode(PDO::FETCH_ASSOC);

        //  print_r($result1); 


        if ($result1 > 0) {

            foreach ($r1 as $row) {

               // $txtBreceipt_id = $row['receipt_id'];
              //  $txtBdate = $row['chk_out_date'];
                //$txtBapp_id = $row['app_id'];
                $txtBclientnme = $row['onamec'];
                 $txtBclientsnme=$row['snamec'];
                $txtBveh_num = $row['veh_num'];

                $txtBdate_app=$row['date_app'];
                $txtBclient_id=$row['client_id'];
            }
        }
    } catch (PDOException $e) {
        echo $result1 . "<br>" . $e->getMessage();
    }
}
?>
                        
                        <?php
             
           
         
       if(isset($_POST['btnBsave']))
       {$txtinvoice=$_POST['txtBreceipt_id'];
             $txtBdate=$_POST['txtBdate'];
          
             $txtBclientsnme=$_POST['txtBclientsnme'];
           $txttotall=$_POST['txtBtotall'];
             $txtBamt_pay=$_POST['txtBamt_pay'];
             $txtB_balance_due=$_POST['txtB_balance_due'];
           $txtBclient_id=$_POST['txtBclient_id'];
          //   $txtBclientnme=$_POST['txtBclientsnme'];
             $txtBapp_id=$_POST['txtBapp_id'];
           echo $txtBclient_id;
              $stmt = $DB_con->prepare("INSERT INTO billing_tbl
              (receipt_id,chk_out_date,total_pay,amt_pay,balance_due,app_id,client_id)
              VALUES('$txtinvoice','$txtBdate','$txttotall','$txtBamt_pay','$txtB_balance_due','$txtBapp_id','$txtBclient_id')");

           /*  $stmt->bindparam(':$txtinvoice', $owner);
              $stmt->bindparam(':$txtsnamec', $snamec);
              $stmt->bindparam(':$txtonamec', $onamec);
              $stmt->bindparam(':$txtdobc', $dobc);
              $stmt->bindparam(':$genderc', $genderc);       
              $stmt->bindparam(':$txtemail', $email);
              $stmt->bindparam(':$txtcontact_num', $contact_num);
              $stmt->bindparam(':$txtdor', $dor);*/

              $stmt->execute(); 
            
                   
               //  return $stmt;

       }        
                        ?>


                    </header>

                    <form  action="" method="post">
                        <article>



                            <h1>Recipient</h1>
                            <address contenteditable>

                                <p>CDD Garage</p>
                                <p>Rue Lees, Curepipe<br> (230)6704747</p>
                                <span>Vehicle Number:<input style="width:150px; height:25px" type="text" name="txtBveh_num" id="Bveh_num" value="<?php echo $txtBveh_num; ?>" /></span> .<br>
                                <span>Date Of Appointment:<input style="width:150px; height:25px" type="text" name="txtBdate_app" id="Bdate_app" value="<?php if (!(empty($txtBdate_app))) {
                                echo $txtBdate_app;
                            } else {
                                echo "";
                            } ?>" /></span>

                            </address>

                            <table class="meta">
                                <tr>
                                    <th><span contenteditable>Invoice #</span></th>
                                    <td><span ><input style="width:140px; height:20px" tystyle="width:100px; height:20px"  type="text" name="txtBreceipt_id" id="receipt_id" value="<?php if (empty($txtBreceipt_id)) echo $last;
                             ?>" /></span><span><button class="button button5" type=""  id="Binvoice" name="btnBinvoice">Search by Invoice:</button></span></td>
                                </tr>
                                <tr>
                                    <th><span contenteditable>Date</span></th>
                                    <td><span ><input style="width:140px; height:20px"  type="text" name="txtBdate" id="Bdate" value="<?php if (empty($txtBdate)) {
                                echo date("Y/m/d");
                            } else {
                                echo $txtBdate;
                            } ?>" size="15" readonly="readonly" /></span></td>
                                </tr>
                                <tr>
                                    <th><button class="button button5" type=""  id="btnSchapp_id" name="btnSchapp_id">Appointment ID:</button></th>
                                    <td><span><input style="width:140px; height:20px"  placeholder="Search By App ID:" type="text" name="txtBapp_id" id="Bapp_id" value="<?php if (!(empty($txtBapp_id))) {
                                echo $txtBapp_id;
                            } else {
                                echo"";
                            } ?>" /></span></td>
                                </tr>
                                <tr>
                                    <th><span contenteditable>Client:<br> OtherName:</span></th>
                                    <td><span ><input style="width:140px; height:20px"  type="textbox" name="txtBclientsnme" id="Bclientsnme" value="<?php if (empty($txtBclientsnme)){echo"";}else{echo $txtBclientsnme;} ?>"/></span></td>
                               
                                </tr>   
                                 <tr>
                                    <th><span contenteditable>
                                            Surname:</span></th>
                                    <td><span contenteditable ><input style="width:140px; height:20px"  type="textbox" name="txtBclientnme" id="Bclientnme" value="<?php if (empty($txtBclientnme)){echo"";}else{echo $txtBclientnme;} ?>"/></span></td>
                                    
                                </tr> 
                                
                                <tr>
                                    <th><span contenteditable >Client ID:</span></th>
                                    <td><span contenteditable ><input style="width:140px; height:20px"  type="textbox" name="txtBclient_id" id="Bclient_id" value="<?php if (empty($txtBclient_id)){echo"";}else{echo $txtBclient_id;} ?>"/></span></td>
                                </tr>
                            </table>
                            <table class="inventory">
                                <thead>
                                    <tr>
                                        <th><span contenteditable>Production Name:</span></th>
                                        <th><span contenteditable>Reference Item:</span></th>

                                        <th><span contenteditable>Quantity:</span></th>
                                        <th><span contenteditable>Price:</span></th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php
                                 //   $txtBtotall=$_POST['txtBtotall'];
                                    
                                    $r3 = $DB_con->query("SELECT depatch_tbl.app_id, 
                                        depatch_tbl.prod_id, depatch_tbl.quantity_rec, 
                                        store_tbl.prod_name, store_tbl.prod_price, store_tbl.ref FROM ((
                                        app_tbl
                                        INNER JOIN depatch_tbl ON app_tbl.app_id = depatch_tbl.app_id
                                        )
                                        INNER JOIN store_tbl ON depatch_tbl.prod_id = store_tbl.prod_id
                                        )
                                        WHERE app_tbl.app_id =".$DB_con->quote($txtBapp_id));

                                   

                                    $r3->execute();

                            $r3->setFetchMode(PDO::FETCH_ASSOC);
                                   // $number_of_rows = $r3->fetchColumn(); 
                                   ///$result3= $r3->fetchInto($row);
                                    //echo"number search: " +$result3;
                            
                                 $result3 = $r3->rowCount();
                                  //print_r($result3);
                            
                            
                             
                                    foreach ($r3 as $row)
                                        {
                                     /* @var $txtprod_name type */
                                       
                                    $txtprod_name = $row['prod_name'];
                                    $txtref = $row['ref'];
                                    $txtquantity = $row['quantity_rec'];
                                    $txtprice = $row['prod_price']; 

                                         $txtprice= $txtquantity*$txtprice;  
                                       
                                
                                        echo "<tr>";
                                        echo"<td>" . $txtprod_name . "</td>";
                                        echo"<td>" . $txtref . "</td>";
                                        echo"<td>" . $txtquantity . "</td>";
                                        echo"<td>" . $txtprice . "</td>";

                                      
                                      
                                        echo"</tr>";
                                       $txtBtotall+=$txtprice;
                                       
                                       //$txtB_balance_due=$txtBtotall-$txtBamt_pay;
                                    }    
                                        
                                     
                                        ?>
                                        
                                   
                                </tbody>
                            </table>

                            <table class="">
                             <script>
                                    
    $(function() {
    $("#Btotall, #Bamt_pay").on("keydown keyup", sum);
	function sum() {
	
	$("#B_balance_due").val(Number($("#Btotall").val()) - Number($("#Bamt_pay").val()));
	}
});
                                    
                                    
                                    </script>
                         
                                <tr>
                                    <th><span>Total(Rs): </span></th>
                                    <td><span><input style="width:140px; height:20px" disabled="disabled" type="text" name="txtBtotall" id="Btotall" value="<?php if(empty($txtBtotall)) {echo"";}else {echo $txtBtotall;} ?>"/></span></td>
                                    
                                       
                                   
                                </tr>
                                <tr>
                                    <th><span>Amount Paid(Rs):</span></th>
                                    <td><span><input style="width:140px; height:20px"  type="text" name="txtBamt_pay" id="Bamt_pay" value="<?php if (!(empty($txtBamt_pay))) {
                                        echo $txtBamt_pay;
                                    } else {
                                        echo "";
                                    } ?>"/></span></td>
                                </tr>
                                <tr>
                                    <th><span>Balance Due(Rs):</span></th>
                                    <td><span><input style="width:150px; height:20px"  type="text" id="B_balance_due" name="txtB_balance_due" value="<?php if (!(empty($txtB_balance_due))) {
                                        echo $txtB_balance_due;
                                    } else {
                                        echo "";
                                    } ?>"/></span> </td>
                                </tr>
                                
                                <?php
                                    if(isset($_POST['btnBsave']))
                                        
                                    {
                                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                    
                                 ?>
                            </table>
                            <table border="1" width="50">
                                <tbody>
                                    <tr>
                                        
                                        <td><span><button class="button1 button2" type="submit" value="Save" name="btnBsave" >Save</button></span>
                                            <span><button class="button1 button2" type="submit" value="Update" name="btnBupdate" >Update</button></span>
                                        
                                            <span><button class="button1 button2" type="submit" value="Clear" onclick="myFunction()" name="btnBclear" >Clear</button></span>
                                        
                                        </td>
                                        
                                     
                                       
                                    </tr>
                                
                                </tbody>
                                
                            </table>

                            
                            
                            
                    </article>
</form>

                    <aside>
                        <h1><span contenteditable>Additional Notes</span></h1>
                        <div contenteditable>
                            <p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
                        </div>
                    </aside>		
                    <div><font size="6" ><a href ="javascript:window.print()">Print</a></div>
                    
                    

                </div>
            </div>

<?php include_once('includes/footer.php'); ?>
    </body>


</div>
</html>
