<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'home';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?>
<?php
 error_reporting(E_ALL ^ E_NOTICE);
 error_reporting(E_ALL ^ E_DEPRECATED);
require_once("dbcontroller.php");
$db_handle = new DBController();

?>
<html>
    <head>
        <title>CDD Service</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="website description" />
        <meta name="keywords" content="website keywords, website keywords" />
        <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
        <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />
		<!Add-on>
		<link href="style/style1.css" type="text/css" rel="stylesheet" />
       <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	   <script>
function showEditBox(editobj,id) {
	$('#frmAdd').hide();
	$(editobj).prop('disabled','true');
	var currentMessage = $("#message_" + id + " .message-content").html();
	var editMarkUp = '<textarea rows="5" cols="80" id="txtmessage_'+id+'">'+currentMessage+'</textarea><button name="ok" onClick="callCrudAction(\'edit\','+id+')">Save</button><button name="cancel" onClick="cancelEdit(\''+currentMessage+'\','+id+')">Cancel</button>';
	$("#message_" + id + " .message-content").html(editMarkUp);
}
function cancelEdit(message,id) {
	$("#message_" + id + " .message-content").html(message);
	$('#frmAdd').show();
}
function cartAction(action,product_code) {
	var queryString = "";
	if(action != "") {
		switch(action) {
			case "add":
				queryString = 'action='+action+'&code='+ product_code+'&quantity='+$("#qty_"+product_code).val();
			break;
			case "remove":
				queryString = 'action='+action+'&code='+ product_code;
			break;
			case "empty":
				queryString = 'action='+action;
			break;
		}	 
	}
	jQuery.ajax({
	url: "ajax_action.php",
	data:queryString,
	type: "POST",
	success:function(data){
		$("#cart-item").html(data);
		if(action != "") {
			switch(action) {
				case "add":
					$("#add_"+product_code).hide();
					$("#added_"+product_code).show();
				break;
				case "remove":
					$("#add_"+product_code).show();
					$("#added_"+product_code).hide();
				break;
				case "empty":
					$(".btnAddAction").show();
					$(".btnAdded").hide();
				break;
			}	 
		}
	},
	error:function (){}
	});
}
</script>
    </head>

    <body>
        <div id="main">
            <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                  
					
       
  
  
  <?php if (isset($_POST['txtsprod_id'])) 
{ 

       
}  ?>
       
     <form action="<?php $_SERVER['PHP_SELF']; ?>"  method="POST">
           
       <table border = "1" width = "200">
   
       <tbody>
       <tr>
         <td>Product ID :<input type="text" name="txtsprod_id" 
	         value="<?php  if(!(empty($sprod))) {echo $sprod;} else {echo ""; }  ?>" 
	     </td>
		</tr>
           <td><input type="submit" value="Search By Product ID" name="btnsprod" /></td> 
		</tr>
      </tbody>
    </table>
   </form>


<div id="product-grid">
	<div class="txt-heading">Products</div>
	<?php  
	    $v = isset($_POST['txtsprod_id']) ? $_POST['txtsprod_id'] : "";
	       
		   
	     $product_array = $db_handle->runQuery("SELECT * FROM store_tbl where  prod_id =" . $v );
		 
	    if (empty($product_array))
	     {
		
		echo "Input Your Product-ID";
	    }

    else

		{ 
		foreach($product_array as $key=>$value){
?>
		<div class="product-item">
			<form id="frmCart">
			<table>
			
			<tr><td><div><strong><?php echo $product_array[$key]["prod_name"]; ?></strong></td></div>
			<td><div class="product-price"><?php echo "Rs".$product_array[$key]["prod_price"]; ?></div></td>
			<td><div><input type="text" id="qty_<?php echo $product_array[$key]["prod_id"]; ?>" name="quantity" value="1" size="4" /></td>
			
		
			<?php
				$in_session = "0";
				if(!empty($_SESSION["cart_item"])) 
				{
					$session_code_array = array_keys($_SESSION["cart_item"]);
				    if(in_array($product_array[$key]["prod_id"],$session_code_array)) 
					{
						$in_session = "1";
				    }
				}
			?>
			<td><input type="button"  id="add_<?php echo $product_array[$key]["prod_id"]; ?>" value="Despatch " class="btnAddAction cart-action" onClick = "cartAction('add','<?php echo $product_array[$key]["prod_id"]; ?>')" <?php if($in_session != "0") { ?>style="display:none" <?php } ?> /></td>
			<td><input type="button" id="added_<?php echo $product_array[$key]["prod_id"]; ?>" value="Added" class="btnAdded" <?php if($in_session != "1") { ?>style="display:none" <?php } ?> /></td>
			</div></tr>
			</table>
			</form>
	     <?php 
			}
	   }
	?>
    </div>
            <div class="clear-float"></div>
              <div id="shopping-cart">
                  <div class="txt-heading">Product and Material Request <a id="btnEmpty" class="cart-action" onClick="cartAction('empty','');">Empty Depatch</a></div>
                     <div id="cart-item"></div>
</div>
             <script>
             $(document).ready(function () 
                    {
	                  cartAction('','');
                     })
</script>

  </div>
  
  </div>
  
</body>
					
			<?php //include_once('includes/footer.php'); ?>		
    
 


        
    
</html>
