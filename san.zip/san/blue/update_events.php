<?php




$connect = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');



if(isset($_POST["id"]))
{
 $query = "UPDATE app_tbl 
 SET service_req=:service_req, start_date=:start_date, end_date=:end_date
 WHERE app_id=:app_id";
  
 
 $statement = $connect->prepare($query);
 $statement->execute(
  array(
  ':service_req'  => $_POST['title'],
   ':start_date' => $_POST['start'],
   ':end_date' => $_POST['end'],
   ':app_id'   => $_POST['id']
  )
 );
 
 
}
header('Location: appointment.php');
?>