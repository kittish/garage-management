<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'home';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?>
<html>
    <head>
        <title>CDD Service</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="website description" />
        <meta name="keywords" content="website keywords, website keywords" />
        <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
        <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />
    </head>
    
     <form action='' method='post'>
                  <?php
                     	if(isset($_POST['btnrstore']))
          {    echo "God Is Great....";     
              /*
         
           try {
           {        
            $r = $DB_con->query("SELECT * FROM store_tbl WHERE prod_id = ".$DB_con->quote($prod_id));
    
            $r->execute();
            $result = $r->setFetchMode(PDO::FETCH_ASSOC);
      
     } 
      
   
      echo'<table border = "1" cellpadding = "2">'  
                            .'<thead>'
                           .'<tr>' 
                            .'<th>'+"Product ID"+'</th>'
                             .'<th>'+"Product Name"+'</th>'
                              .'<th>'+"Product Reference"+'</th>'
                               .'<th>'+"Price"+'</th>'
                                 .'<th>'+"Quantity"+'</th>'
                                  .'<th>'+"Date Record"+'</th>'
                            
                           .'</tr>' 
                            .'</thead>'
                            .'<tbody>';
                foreach($r as $row)
     
            {  
                          echo '<tr>' 
                            .'<td>'+$row['prod_id']+'</td>'
                              .'<td>'+$row['prod_name']+'</td>'
                                .'<td>'+$row['ref']+'</td>'
                                  .'<td>'+$row['prod_price']+'</td>'
                                  .'<td>'+$row['quantity']+'</td>'
                                  .'<td>'+$row['date_rec']+'</td>'
                           
                            .'</tr>';
                           
                         
                  
           
             }    
           echo'</tbody>' 
                           .'</table >' ;
     }
           catch(PDOException $e)
           {echo "Error occurs:". $e->getMessage();}
               */             
          }  

                
                    
                    ?>
         
         
     </form>>
    <body>
        <div id="main">
            <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                    <h2>To Generate A Report Of Store</h2>
                   
                    <table border="1" cellpadding="2">
                       
                        <tbody>
                            <tr>
                                <td><input type="text" name="txtrsearch" value="" /></td>
                                <td><input type="submit" value="ID" name="btnrstore"/></td>
                               
                                <?php
                                if(isset($_POST['btnrstore']))
                                    
                                
                                    
                                ?>
                                    
                            </tr>
                        </tbody>
                    </table>
                    
                    
  

                </div>           
            </div>
        </div>

        <?php include_once('includes/footer.php'); ?>
    </body>
</html>
