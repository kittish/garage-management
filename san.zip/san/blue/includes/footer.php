<div id="footer">
    Copyright &copy; CDD Garage | <a href="http://validator.w3.org/check?uri=referer">Lees Street</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">Curepipe</a> | <a href="http://www.html5webtemplates.co.uk"></a>
</div>