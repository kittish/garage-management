<?php
             $txtinvoice=$_POST['txtBreceipt_id'];
             
             $txtdate=$_POST['txtBdate'];
             $txtBclientnme=$_POST['txtBclientnme'];
             $txtBclientsnme=$_POST['txtBclientsnme'];
             $txttotall=$_POST['txttotall'];
             $txtBamt_pay=$_POST['txtBamt_pay'];
             $txtB_balance_due=$_POST['txtB_balance_due'];
           
           $err3="";
           $err2="";
           $err1="";
           $err4="";
           $err5="";
           $err6="";
           $err7="";
           $err8="";
           $err9="";
       if(isset($_POST['btnBsave']))
       {
                    
              
         /*    if (empty($owner))
              
                 { $err1="Please select in drowndrop list..."; }
              
                  
             
            else if (is_numeric($owner))
                
                {$err1="Numeric value is not accepted "; }
                    
                  else if (empty($snamec))
                
                   { $err2 ="please input surname..";}   
               
                 else if (is_numeric($snamec))
                     
                     {$err2=" Input only alphabetical letters....   "; }
               
                    
                 else if (empty($onamec))
                { $err3 ="please input Othername..";  }
                
                   else if (is_numeric($onamec))
                     
                     {$err3=" Input only alphabetical letters....   ";}
                         
                  else if(empty($dobc)) 
                   
                   {$err4="Please enter the correct date: YY-MM-DD"; }         
                         
                    
                  ///////////////////////////////////////////////
              else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $dobc))
                  
                   {$err4=" The format date is incorrect....";}  
                    
                   
                 else  if(empty($genderc))
            {$err5="Please select gender..";  }     
              
                
              else  if(empty($email))
			  {$err6="Please fill the email address";  }
               
            else  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
            {$err6="Input a correct email address...";  } 
                     
            elseif (empty($contact_num)) 
            
            {$err7 = "Input Contact Number ";}
            
           elseif((is_numeric(strlen($contact_num)) >6)or (is_numeric(strlen($contact_num))<9))
               
           {$err7 ="Input Contact Number between  7 to 8 numerical value..";}
           
           else if(!preg_match("/^([2-9]{1})([0-9]{6})$/", $contact_num))
                       {$err7="The numerical must not start 0,1";}

            else if(empty($dobc)) 
                
                   
              { $err8="Please enter the correct date: YY-MM-DD"; }     
           
            else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $dor))
				 
                  {$err8=" The format date is incorrect....";  }   
                else
       
         try { */
    
         
         
         
              $stmt = $DB_con->prepare("INSERT INTO billing_tbl
              (invoice,chk_out_date,onamecb,snamecb,total_pay,amt_pay,balance_due,app_id)
              VALUES('$txtBreceipt_id','$txtBdate','$txBclientsnme','$txtBclientnme','$txtBtotal','$txtBamt_pay','$txtB_balance_due')");

            /*  $stmt->bindparam(':$ddlowner', $owner);
              $stmt->bindparam(':$txtsnamec', $snamec);
              $stmt->bindparam(':$txtonamec', $onamec);
              $stmt->bindparam(':$txtdobc', $dobc);
              $stmt->bindparam(':$genderc', $genderc);       
              $stmt->bindparam(':$txtemail', $email);
              $stmt->bindparam(':$txtcontact_num', $contact_num);
              $stmt->bindparam(':$txtdor', $dor);
*/
              $stmt->execute(); 
            
                   
               //  return $stmt;
            
                 //$User->redirect('billing.php');
          /*  }
                 catch(PDOException $e)
                 {
                   echo $e->getMessage();
                 }
            */
         
                
        }

?>