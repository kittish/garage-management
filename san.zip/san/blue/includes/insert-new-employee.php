<?php
      error_reporting(E_ALL ^ E_NOTICE);
      error_reporting(E_ALL ^ E_DEPRECATED);
      
   //  include_once 'dbconfig.php';
    
        $sname=null;
        $dob="";
        $gender="";
		$ddlgender="";
        $basic_sal = "";
        $o_time_rate = "";
        $emp_id="";
        $doe ="";
        $str="";
        $check1=null;
        $check2=null;
        $check3=null;
        $check4=null;
		$chqk="";
		$strchkq="";
          /* */
           $err3="";
           $err2="";
           $err1="";
           $err4="";
           $err5="";
           $err6="";
           $err7="";
           $err8="";
           $err9="";
           
           
         
       if(isset($_POST['btnadd']))
       { 
           $sname =$_POST['txtsname'];
           $oname = $_POST['txtoname'];
           $dob = $_POST['txtdob'];
           $jobtittle = $_POST['txtjobtittle'];
           $basic_sal = $_POST['txtbasic_sal'];
           $o_time_rate = $_POST['txto_time_rate'];
           $gender = $_POST['dllgender'];
           $chkq =  $_POST['chkq'];
           $strchkq = implode(',', $_POST['chkq']);
           $doe =$_POST['txtdoe'];
   
          
          
         
            
             
          
           
      /*  if(empty($sname)&&empty($oname)&&empty($jobtittle)&&empty($dob&&$dob)&&empty($basic_sal)&&empty($strchkq)&&empty($doe))   
  
        {$err1=$err2=$err3=$err4=$err5=$err6=$err7=$err8=$err9="Input Required....";
        
        exit();
        }
           
           
        else*/ if (empty($sname))
          {$err1 = "Please Surmane in text !"; } 
                
          else if(is_numeric($sname))
             
           {$err1= "Input Alphabetical Words only "; }
                   
           else if(empty($oname))
                  
           {$err2 ="Enter Other Name Please..";}
          
            else if(is_numeric($oname))
							
             {$err2= "Input Alphabetical Words only ";}
                   
              else if(empty($jobtittle))
						  
                {$err3 ="Enter  jobtititle Please..";}
				  
               else if(is_numeric($jobtittle))
							   
                  {$err3= "Input Alphabetical Words only ";}
          
                  else if(empty($dob)) 
                 
                     { $err4="Please enter the correct date: YY-MM-DD"; }
                 
                    else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $dob))
               
                        {$err4=" The format date is incorrect dob...:YY-MM-DD";}
                   
                      else if(empty($basic_sal) ) 
                  
                            {$err5="Input basic sum salary number...";}
           
                        else if(!is_numeric($basic_sal)) 
            
                          {$err5=" PLESE INPUT NUMBER ONLY";}
                  
                         else if(empty($o_time_rate) )
                           { $err6="Input over tine rate";}
              
           
                          else if(!is_numeric($o_time_rate))
               
                            {$err6="Input over time in numeric format";}
           
                            else  if(empty($gender))///  error display message is not working....
                              {$err7="Please chose gender"; } 
                        
                  
                              else if( empty($strchkq))
                
                                {$err8=" Please select ur Qualification";  }

                               else if (empty($doe) )
                 
                                { $err9 ="Please Input Date Of Entry"; }
                    
                                  else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $doe))
                    
                                     {$err9=" Check Your Date Format : YY:MM:DD" ;}     
             else
       
         try { 
    
        
        
$stmt = $DB_con->prepare("INSERT INTO emp_tbl(emp_id,sname,oname,dob,job_tittle,basic_sal,o_time_rate,gender,qualification,date_entry)
			  
			  VALUES('$emp_id','$sname','$oname','$dob','$jobtittle','$basic_sal','$o_time_rate','$gender','$strchkq','$doe')"); 
             
         
          
              $stmt->bindparam(':$txtemp_id' , $emp_id);
              $stmt->bindparam(':$txtsname', $sname);
              $stmt->bindparam(':$txtoname', $oname);
              $stmt->bindparam(':$txtdob', $dob);     
              $stmt->bindparam(':$txtjobtittle', $jobtittle);
              $stmt->bindparam(':$txtbasic_sal', $basic_sal);
              $stmt->bindparam(':$txto_time_rate', $o_time_rate);
              $stmt->bindparam(':$ddlgender', $gender);       
              $stmt->bindparam(':$strchkq', $strchkq);
              $stmt->bindparam(':$txtdoe', $doe);
               
              $stmt->execute(); 
            
                          
                 return $stmt;
            $id = mysql_query("SELECT * FROM emp_tbl WHERE emp_id=LAST_INSERT_ID()")or die(mysql_error());
                 $User->redirect('reg_employee.php');
             
    
            
            
            
            }
			
			
                 catch(PDOException $e)
                 {
                   echo $e->getMessage();
                 }
       }
                     
                  
                     
             
      
       
      
          if(isset($_POST['btnsearch1']))
            {        
             
             $emp_id =$_POST['txtemp_id'];
             
                 
                 
            
             try {

                  
                                      
                    $r = $DB_con->query("SELECT * FROM emp_tbl WHERE emp_id = ".$DB_con->quote($emp_id));
                    $r->execute();
                    $result = $r->setFetchMode(PDO::FETCH_ASSOC);
                    
                    
                 
                if($result> 0)
                 { echo  $result;
      
                   foreach($r as $row)
     
                       
        
                    $emp_id=$row['emp_id'];
                    $sname =$row['sname'];  
                    $oname = $row['oname'];
                    $dob = $row['dob'];
                    $jobtittle = $row['job_tittle'];
                    $basic_sal = $row['basic_sal'];
                    $o_time_rate = $row['o_time_rate'];
                    $doe =$row['date_entry'];   
                    $gender=$row['gender'];  
                    $str=($row['qualification']);
                    $data=(explode(",",$str));
                    $check=array("Vocational","SC","HSC","Degree");
            
            
            if(in_array($check[0],$data))
                { $check1="checked"; }
              else
                {$check1="";}
              if(in_array($check[1],$data))
                 { $check2="checked";}
               else
                 {$check2="";}
            
                  if(in_array($check[2],$data))
                    { $check3="checked"; }
                   else
                    {$check3=""; }
                
                    if(in_array($check[3],$data))
                     { $check4="checked"; }
                       else
                     {$check4=""; }
             
				 }
             
               
             }
              
             
            
            catch(PDOException $e)
                     {echo "Error occurs:". $e->getMessage();}  
                     
                     
            }
             
       if(isset($_POST['btnupdate']))
 {
       try
        { 
       
           $emp_id= $_POST['txtemp_id'];
           $sname = $_POST['txtsname'];  
           $oname = $_POST['txtoname'];
           $dob = $_POST['txtdob'];
           $jobtittle = $_POST['txtjobtittle'];
           $basic_sal = $_POST['txtbasic_sal'];
           $o_time_rate = $_POST['txto_time_rate'];
           $gender = $_POST['dllgender'];
           $strchkq = implode(',', $_POST['chkq']);
           $doe =$_POST['txtdoe'];
		  
		     $upd = "UPDATE emp_tbl SET sname='$sname',oname='$oname', job_tittle = '$jobtittle',dob = '$dob',basic_sal='$basic_sal',o_time_rate ='$o_time_rate',gender='$gender',qualification='$strchkq',date_entry ='$doe' WHERE emp_id= $emp_id";
 
              // Prepare statement
                  $stmtup = $DB_con->prepare($upd);
 
             // execute the query
                  $stmtup->execute();

         }
            catch(PDOException $e)
                     {  echo $upd . "<br>" . $e->getMessage(); }
                     
    }              
                    
   
    

 


          
    
    
             if(isset($_POST['btndelete1']))
             {  
                 $emp_id= $_POST['txtemp_id'];
                 
                 $select ="select * from emp_tbl where emp_id=$emp_id";
                 
      
                    if (empty($emp_id))
                              {
                                  echo "This Id do not exist....";
                                  exit();
                              }
                              
                                 else 
                          { 
                 
                  
                 
                            try {
                              
                              
                                  
                                 // sql to delete a record
                                  $del = "DELETE FROM emp_tbl WHERE emp_id=$emp_id";

                                 // use exec() because no results are returned
                                   $DB_con->exec($del);
                                }
     
   
                          catch(PDOException $e)
                         
                            {echo $del . "<br>" . $e->getMessage(); }
                      
                                                                      


                }
             }   
     
    ?>