<div id="header">
    <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">CDD Garage<span class="logo_colour">Management</span></a></h1>
          
        </div>
    </div>
    <div id="menubar">
        <ul id="menu">
            <li class="<?php echo (!empty($currentPage) && $currentPage == 'home')?'selected':''; ?>">
                <a href="index.php">Home</a>
            </li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logOut">
              <a href="logout.php?logout=true">welcome :<?php print($userRow['uname']);?>, <i class="glyphicon glyphicon-log-out">logout</i> </a>
            </li>
        </ul>
    </div>
</div>