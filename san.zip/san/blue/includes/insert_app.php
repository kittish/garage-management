<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
            $txtapp_id="";  
           $client_id="";
           $txtveh_num ="";
           $txtapp_date_time="";
           
           $ddlduration ="";
           $ddlmechanic ="";
           $ddlteam ="";
        
           $chk_ele="";
           $chk_quotation="";
           $txtinfo="";
           
           
           $err3="";
           $err2="";
           $err1="";
           $err4="";
           $err5="";
           $err6="";
           $err7="";
           $err8="";
           $err9="";
       if(isset($_POST['btnsave2']))
       {
            $txtapp_id=trim($_POST['txtapp_id']);  
           $client_id=trim($_POST['txtclient_id']);
           $txtveh_num = trim($_POST['txtveh_num']);
           $txtapp_date_time=trim($_POST['$txtapp_date_time']);
           $ddlduration = trim($_POST['ddlduration']);
           $ddlmechanic = trim($_POST[' $ddlmechanic']);
           $ddlteam = $_POST['ddlteam'];
           
           $chk_ele = trim($_POST['chk_ele']);
           $chk_quotation = trim($_POST['chk_quotation']);
          $txtinfor =$_POST['txtinfor'];
          
             if (empty($txtclient_id))
              
                 { $err1="Please select in drowndrop list..."; }
              
                  
             
            else if ($txtveh_num)
                
                {$err2="Numeric value is not accepted "; }
                    
                  else if (empty($txtapp_date_time))
                
                   { $err3 ="please input date..";}   
               
                 else if (is_numeric($ddlduration))
                     
                     {$err4=" Please select your duration....   "; }
               
                    
                 else if (empty($ddlmechanic))
                { $err5 ="please Select your Service..";  }
                
                   else if ($ddlteam)
                     
                     {$err6=" Please Select your Team....   ";}
                         
                 /* else if(empty($txtinfor)) 
                      
                  {
                      $err5 =" ";
                  }*/
                   
                   else
       
         try { 
    
         
         
         
              $stmt = $DB_con->prepare("INSERT INTO app_tbl
              (client_id,veh_num,app_date_time,duration,service_req,quotation,infor)
              VALUES('$owner','$snamec','$onamec','$dobc','$genderc','$email','$contact_num','$dor','$contract_id')");

              $stmt->bindparam(':$ddlowner', $owner);
              $stmt->bindparam(':$txtsnamec', $snamec);
              $stmt->bindparam(':$txtonamec', $onamec);
              $stmt->bindparam(':$txtdobc', $dobc);
              $stmt->bindparam(':$genderc', $genderc);       
              $stmt->bindparam(':$txtemail', $email);
              $stmt->bindparam(':$txtcontact_num', $contact_num);
              $stmt->bindparam(':$txtdor', $dor);

              $stmt->execute(); 
            
                   
                 return $stmt;
            
                 $User->redirect('appointment.php');
            }
                 catch(PDOException $e)
                 {
                   echo $e->getMessage();
                 }
            
         
                
        }
?>