﻿
<?php
// Values received via ajax



if(isset($_POST['btnsave2']))
    
{
$client_id = $_POST['client_id'];
$veh_num = $_POST['veh_num'];
$service_req = $_POST['service_req'];
$infor = $_POST['infor'];

// connection to the database
try {
$bdd = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');
} catch(Exception $e) {
exit('Unable to connect to database.');
}

// insert the records
$sql = "INSERT INTO app_tbl (app_id,client_id,date_app, veh_num,service_req, start_date,end_date,infor,allDay)VALUES ('','".$client_id."',CURRENT_TIMESTAMP, '".$veh_num."','".$service_req."','', '','".$infor."','true')";
$q = $bdd->prepare($sql);
$s[]=$q->execute(array(
    ':app_id'=>'',
    ':client_id'=>$client_id,
    ':date_app'=>'CURRENT_TIMESTAMP',
    ':veh_num'=>$veh_num, 
    ':service_req'=>$service_req, 
    ':start_date'=>'',
    ':end_date'=>'',
    ':infor'=>$infor
 
     ));


     //print_r($s);

// INSERT INTO app_tbl (app_id,client_id,date_app, veh_num,service_req, start_date,end_date,infor,allDay) VALUES ('',77,'', 444,'servicing' ,'2018-04-05', '2018-04-07','infor','true');
}



?>