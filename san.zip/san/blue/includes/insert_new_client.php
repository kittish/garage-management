

 <?php $client_id="";
           $owner="";
           $snamec ="";  
           $onamec = "";
           $dobc = "";
           $genderc="";
           $email ="";
           $contact_num = "";
           $dor="";
           $contract_id = "";
           
           $errsnamec="";
           
           
           $err3="";
           $err2="";
           $err1="";
           $err4="";
           $err5="";
           $err6="";
           $err7="";
           $err8="";
           $err9="";
       if(isset($_POST['btnsave2']))
       {
                
           $client_id=trim($_POST['txtclient_id']);
           $owner=trim($_POST['ddlowner']);
           $snamec = trim($_POST['txtsnamec']);
           $onamec = trim($_POST['txtonamec']);
           $dobc = trim($_POST['txtdobc']);
           $genderc = $_POST['genderc'];
           $email = trim($_POST['txtemail']);
           $contact_num = trim($_POST['txtcontact_num']);
           $dor =$_POST['txtdor'];
           $contract_id=$_POST['txtcontract_id'];
           
             if (empty($owner))
              
                 { $err1="Please select in drowndrop list..."; }
              
                  
             
            else if (is_numeric($owner))
                
                {$err1="Numeric value is not accepted "; }
                    
                  else if (empty($snamec))
                
                   { $err2 ="please input surname..";}   
               
                 else if (is_numeric($snamec))
                     
                     {$err2=" Input only alphabetical letters....   "; }
               
                    
                 else if (empty($onamec))
                { $err3 ="please input Othername..";  }
                
                   else if (is_numeric($onamec))
                     
                     {$err3=" Input only alphabetical letters....   ";}
                         
                  else if(empty($dobc)) 
                   
                   {$err4="Please enter the correct date: YY-MM-DD"; }         
                         
                    
                  ///////////////////////////////////////////////
              else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $dobc))
                  
                   {$err4=" The format date is incorrect....";}  
                    
                   
                 else  if(empty($genderc))
            {$err5="Please select gender..";  }     
              
                
              else  if(empty($email))
			  {$err6="Please fill the email address";  }
               
            else  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
            {$err6="Input a correct email address...";  } 
                     
            elseif (empty($contact_num)) 
            
            {$err7 = "Input Contact Number ";}
            
           elseif((is_numeric(strlen($contact_num)) >6)or (is_numeric(strlen($contact_num))<9))
               
           {$err7 ="Input Contact Number between  7 to 8 numerical value..";}
           
           else if(!preg_match("/^([2-9]{1})([0-9]{6})$/", $contact_num))
                       {$err7="The numerical must not start 0,1";}

            else if(empty($dobc)) 
                
                   
              { $err8="Please enter the correct date: YY-MM-DD"; }     
           
            else if(!preg_match("/^([0-9]{4})-([0-1][0-9])-([0-3][0-9])$/", $dor))
				 
                  {$err8=" The format date is incorrect....";  }   
                else
       
         try { 
    
         
         
         
              $stmt = $DB_con->prepare("INSERT INTO client_tbl
              (ownership,snamec,onamec,dobc,genderc,email,contact_num,date_reg,contract_id)
              VALUES('$owner','$snamec','$onamec','$dobc','$genderc','$email','$contact_num','$dor','$contract_id')");

              $stmt->bindparam(':$ddlowner', $owner);
              $stmt->bindparam(':$txtsnamec', $snamec);
              $stmt->bindparam(':$txtonamec', $onamec);
              $stmt->bindparam(':$txtdobc', $dobc);
              $stmt->bindparam(':$genderc', $genderc);       
              $stmt->bindparam(':$txtemail', $email);
              $stmt->bindparam(':$txtcontact_num', $contact_num);
              $stmt->bindparam(':$txtdor', $dor);

              $stmt->execute(); 
            
                   
                 return $stmt;
            
                 $User->redirect('reg_client.php');
            }
                 catch(PDOException $e)
                 {
                   echo $e->getMessage();
                 }
            
         
                
        }
       
     if(isset($_POST['btnsearch2']))
          {        
             
             
             $client_id =$_POST['txtclient_id'];
             
             echo"search ok";
            
           try {

                   

                
               
               
                                      
                      $r = $DB_con->query("SELECT * FROM client_tbl WHERE client_id = ".$DB_con->quote($client_id));
    
                      $r->execute();
                       $result = $r->setFetchMode(PDO::FETCH_ASSOC);
                
    
      
    //$txtsname = trim($_POST['txtsname']);
           foreach($r as $row)
           {
               $client_id=$row['client_id'];
               $owner=$row['ownership'];
               $snamec =$row['snamec']; 
               $onamec = $row['onamec'];
               $dobc = $row['dobc'];
               $genderc = $row['genderc'];
               $email = $row['email'];
               $contact_num = $row['contact_num'];
               $dor =$row['date_reg'];
               $contract_id = $row['contract_id']; 
        
                         
            }
               
           }
           catch(PDOException $e)
           {echo "Error occurs:". $e->getMessage();}
                            
          }   
              
            
            
           
          
          
          
       if(isset($_POST['btnupdate2'])){
       try
        { 
       
           $txtclient_id=$_POST['txtclient_id'];
           $ddlowner=$_POST['ddlowner'];
           $txtsnamec = $_POST['txtsnamec'];
           $txtonamec = $_POST['txtonamec'];
           $txtdobc = $_POST['txtdobc'];
          
           $genderc = $_POST['genderc'];
            $txtemail = $_POST['txtemail'];
           $txtcontact_num = $_POST['txtcontact_num'];
          
           $txtdor =$_POST['txtdor'];
           
           $txtcontract_id=$_POST['txtcontract_id'];
 
      
 $upd = "UPDATE client_tbl SET ownership='$ddlowner', snamec='$txtsnamec',onamec='$txtonamec',dobc='$txtdobc',
genderc='$genderc',email='$txtemail' ,contact_num='$txtcontact_num', date_reg = '$txtdor',contract_id='$txtcontract_id' WHERE client_id= $txtclient_id";


// Prepare statement
    $stmtup = $DB_con->prepare($upd);

    // execute the query
    $stmtup->execute();
    
    
    }
 catch(PDOException $e)
    {//   
    echo $upd . "<br>" . $e->getMessage();
    }
	   }

//$DB_con = null;
          
    
    
    if(isset($_POST['btndelete2']))
        
    {   $txtclient_id= trim($_POST['txtclient_id']);
        
        try {
  
    // sql to delete a record
    $del = "DELETE FROM client_tbl WHERE client_id=$txtclient_id";

    // use exec() because no results are returned
    $DB_con->exec($del);
    echo "Record deleted successfully";
    }
catch(PDOException $e)
    {
    echo $del . "<br>" . $e->getMessage();
    }


    }
          
          
          
          
          
                
                             
    
    
   
          if(isset($_post['btnreset2']))
              
              
        
    { 
              echo"resest";
    
         $client_id="";
         
         $snamec="";
         $dobc="";
         $genderc="";
         $contact = "";
         $o_time_rate = "";
         
        $dor ="";
        $str="";
      
    }
    ?>
