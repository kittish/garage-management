 <ul>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'home')?'selected':''; ?>"><a href="home.php">Home Page</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'appointment')?'selected':''; ?>"><a href="appointment.php">Appointment</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'creat.employee.login')?'selected':''; ?>"><a href="creat.employee.login.php">Create Employee Login</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'reg_client')?'selected':''; ?>"><a href="reg_client.php">Client Registration</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'reg_employee')?'selected':''; ?>"><a href="reg_employee.php">Employee Registration</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'store')?'selected':''; ?>"><a href="store.php">Store</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'billing')?'selected':''; ?>"><a href="billing.php">Billing</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'vehicle')?'selected':''; ?>"><a href="vehicle.php">Vehicle</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'marketting')?'selected':''; ?>"><a href="marketting.php">Marketing</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'maintenace')?'selected':''; ?>"><a href="maintenace.php">Maintenance</a></li>
	 <li class="<?php echo (!empty($currentPage) && $currentPage == 'quotation')?'selected':''; ?>"><a href="quotation.php">Quotation</a></li>
    <li class="<?php echo (!empty($currentPage) && $currentPage == 'contact')?'selected':''; ?>"><a href="contactus.php">Contact Us</a></li>
</ul>