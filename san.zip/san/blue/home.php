<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'home';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?>
<html>
    <head>
        <title>CDD Service</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="website description" />
        <meta name="keywords" content="website keywords, website keywords" />
        <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
        <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />
    </head>

    <body>
        <div id="main">
            <?php include_once('includes/header.php'); ?>
            <div id="site_content">
                <div class="sidebar">
                    <?php include_once('includes/sidebar.php'); ?>
                </div>
                <div class="pageContent">
                    <h2>Homepage Title</h2>
                    <p>This is the homepage content</p>
                </div>           
            </div>
        </div>

        <?php include_once('includes/footer.php'); ?>
    </body>
</html>
