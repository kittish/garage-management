<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();


error_reporting(E_ALL ^ E_DEPRECATED);


if(!empty($_POST["action"])) {
switch($_POST["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM store_tbl WHERE prod_id='" . $_POST["code"] . "'") or  die(mysql_error());
			
			$itemArray = array($productByCode[0]["prod_id"]=>array('name'=>$productByCode[0]["prod_name"], 'code'=>$productByCode[0]["prod_id"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["prod_price"]));
			print_r($itemArray);
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["prod_id"],$_SESSION["cart_item"])) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["code"] == $k)
								$_SESSION["cart_item"][$k]["quantity"] = $_POST["quantity"];
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_POST["code"] == $k)
						unset($_SESSION["cart_item"][$k]);
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;		
}
}
?>
<?php
if(isset($_SESSION["cart_item"])){
    $item_total = 0;
?>	
<form  action="despatch-cart.php" method="post" >

<table cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th><strong>Name</strong></th>
<th><strong>Code</strong></th>
<th><strong>Quantity</strong></th>
<th><strong>Price</strong></th>
</tr>	
<?php		
    foreach ($_SESSION["cart_item"] as $id => $item){
		?>      
				<tr>
				<td><strong><?php echo $item["name"]; ?></strong></td>
				<td><?php echo $item["code"]; ?></td>
				<td><?php echo $item["quantity"]; ?></td>
				<td align=right><?php echo "Rs".$item["price"]; ?></td>
				<td>
					<a onClick="cartAction('remove','<?php echo $item["code"]; ?>')" class="btnRemoveAction cart-action">Remove Item</a>
					<input type="hidden" name="product[<?php echo $id; ?>][id]" value="<?php echo $id; ?>" />
					<input type="hidden" name="product[<?php echo $id; ?>][quantity]" value="<?php echo $item["quantity"]; ?>" />
				</td>
				
				
				
				
				</tr>
				<?php
				$i=$item["name"];
				$c=$item["code"];
				$q=$item["quantity"];
				$p=$item["price"];
				$item_total;
				
        $item_total += ($item["price"]*$item["quantity"]);
		}
		
		
		
		?>
		
		<?php
		  if(isset($_POST["dsubmit"]))
		{  echo" despatch button is working";
			
			$sql = "INSERT INTO depatchtbl (despatch_code,name,code, quatity, tprice, depatch_time)VALUES ('','$i', '$c', '$q','$p','')";


                 if ($conn->query($sql) === TRUE) 
				         {
                         echo "New record created successfully";
                         }             
						 else
	                     {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                          }
			
		}
		
		
		?>

<tr>
<td colspan="5" align=right><strong>Total:</strong> <?php echo "$".$item_total; ?></td>

</tr>
<tr>
	<td align="right" colspan="4">
		Vehicle Number :  <input type="text" name="veh_num" required />
		Appointment ID :  <input type="text" name="app_id" required />
	</td>
	<td><button>Despatch</button></td>
	
	
	
	
</tr>
</tbody>
</table>	
	
</form>	
  <?php
  
  
  
}
?>