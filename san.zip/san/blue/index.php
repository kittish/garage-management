<?php
require_once 'dbconfig.php';

if($user->is_loggedin()!="")
{
	$user->redirect('home.php');
}

if(isset($_POST['btn-login']))
{
	$unametxt = $_POST['txt_uname'];
	
	$upasstxt = $_POST['txt_password'];
		
	if($user->login($unametxt,$upasstxt))
	{
            
            
            
		$user->redirect('home.php');
	}
	else
	{
		$error = "Wrong Details !";
	}	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css"  />
 <link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
</head>
<style>
.container1

{  

    position:relative;
    margin:auto;
	top:80px;
	border: 1px solid black;
	max-width:600px;
    outline-style: double;
    outline-color: blue;
	padding:10px;
	
    
	
	
}

.center
{
	
	padding-top: 90px;
    padding-right: 20px;
    padding-bottom: 0px;
    padding-left: 20px;
	
    left: 0;
    top: 50%;
    width: 50%;
    
}
h1 {
    font-size: 40px;
}
</style>
<body>
    <div class="container1">
    	<div class="center">
        <form method="post">
            <h1>Login Form</h1><hr />
            <?php
			if(isset($error))
			{
					 ?>
                     <div class="alert alert-danger">
                        <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error;?> !
                     </div>
                     <?php
			}
			?>
            <div class="form-group">
            	<input type="text" class="form-control" name="txt_uname" placeholder="Username " required />
            </div>
            <div class="form-group">
            	<input type="password" class="form-control" name="txt_password" placeholder="Your Password" required />
            </div>
            <div class="clearfix"></div><hr />
            <div class="form-group">
            	<button type="submit" name="btn-login" class="btn btn-block btn-primary">
                	<i class="glyphicon glyphicon-log-in"></i>&nbsp;SIGN IN
                </button>
            </div>
            <br />
           
        </form>
       </div>
</div>

</body>
</html>