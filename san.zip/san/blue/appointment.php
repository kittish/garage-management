
<?php



// Include the connection of database
      include_once 'dbconfig.php';

      $currentPage = 'appointment';

if(!$user->is_loggedin())
   {
	$user->redirect('index.php');
   }
      //slogin() ;
      $uname = $_SESSION['user_session'];

      $stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
      $stmt->execute(array(":uname"=>$uname));
      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
      
      $base_url = (isset($_SERVER['HTTPS'])?'https:':'http:').'//' . $_SERVER['HTTP_HOST'] . substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], "/") + 1);
// include'includes/add_events1.php';
?>



<head>
     <meta charset='utf-8' />
	<title>CDD Service</title>
	<link href='css/fullcalendar.css' rel='stylesheet' />
	<link href='css/fullcalendar.print.css' rel='stylesheet' media='print' />
	<meta name="description" content="website description" />
	<meta name="keywords" content="website keywords, website keywords" />
	<meta http-equiv="content-type" content="text/html; charset=windows-1252" />
	<link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" title="style" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.structure.min.css" title="style" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.theme.min.css" title="style" />

	<link href='css/fullcalendar.css' rel='stylesheet' />
	<title>Appointment Calendar</title>
	<script src='js/moment.min.js'></script>
	<script src='js/jquery.min.js'></script>
	<script src='js/jquery-ui.custom.min.js'></script>
	<script src='js/fullcalendar.min.js'></script>
	<script>
		var base_url = "<?php echo $base_url; ?>";
	$(document).ready(function() {
		
		var calendar = $('#calendar').fullCalendar({
			header: {
				left 	: 'prev,next today',
				center 	: 'title',
				right 	: 'month,agendaWeek,agendaDay'
                                
                                
                                
                               
			},
                        
                    
                        
                        allDayDefault: false,
			//defaultDate 	: '2018-01-12',
			editable 	: true,
			eventLimit 	: true, // allow "more" link when too many events
                         events 	: base_url +'events.php',
			 
			selectable 	: true,
                       selectHelper 	: true,
		 	editable 	: true,
                         
                         
                   
                         
                         
              
           select: function(start, end, allDay) {
				
				$( "#add-appointment #start-date" ).val($.fullCalendar.formatDate(start, "yyyy-MM-dd HH:mm:ss"));
				$( "#add-appointment #end-date" ).val($.fullCalendar.formatDate(end, "yyyy-MM-dd HH:mm:ss"));
				$( "#add-appointment #all-day" ).val(allDay);
                                $( "#add-appointment #all-day" ).val(allDay);
				
				$( "#add-appointment" ).dialog();
                                
                            
	            
             	calendar.fullCalendar('unselect');
         	},	 
                
                
             eventRender: function(event, element)
			{ 
                            
              element.find('.fc-event-title').append("<br>" +" id: " + event.id); 
            }, 
                
			 
         	eventDrop : function(event) {
         		start 	= $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
             	   	end= $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss");
                        var title = event.title;
                        var id = event.id;
				console.log(event);
				console.log(end);
         		$.ajax({
             		url 	: base_url + 'update_events.php',
              		data  	:   'title='+ title+'&start='+ start +'&end='+ end +'&id='+id,
                         type 	: "POST",
              		success : function() {
                            alert("id eventDrop: "+ id);
                            alert("title eventDrop: " + title);
                            alert("start eventDrop: " + start);
                            alert("end eventDrop: " + end);
                                
                                calendar.fullCalendar('refetchEvents');
              			alert("Event updated");
                   
                   	}
                        
                        
              	});
          	},
			  
          	eventResize: function(event) {
              	start 	= $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
              	end 	= $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss");
                 var title = event.title;
                    var id = event.id;
				console.log(start);
				console.log(end);
          		$.ajax({
					url 	: base_url + 'update_events.php',
					data  	: 'title='+ title+'&start='+ start +'&end='+ end +'&id='+ id,
					type 	: "POST",
					success : function(json) {
                                            
                            alert("id eventResize: "+ id);
                            alert("title eventResize : " + title);
                            alert("start eventResize: " + start);
                            alert("end eventResize: " + end);
                            
			    alert("Event resize updated");
                         calendar.fullCalendar('refetchEvents');
					}
                });
            },
			  
          	eventClick: function(calEvent, jsEvent, view) {
          		$currentEvent = $(this);
			    if (confirm("Do you want to delete this event?") == true) {
			        $.ajax({
						url 		: base_url + 'delete_events.php',
						data 		: 'app_id='+ calEvent.id ,
						type 		: "POST",
						success 	: function(json) {
							$currentEvent.remove();
							alert("Event deleted");
						}
	                });
			    }
		    }
		});
	});
	</script>
        
        
        <script>
        
        function validateForm() 
 {
    var x = document.forms["appfrm"]["client_id"].value;
    if (isNaN(x))
    {
        alert("Name must be filled out");
        return false;
    }
  }
        
        </script>
</head>

	<body>
		<div id="main">
			<?php include_once('includes/header.php'); ?>
	    	<div id="site_content">
		      	<div class="sidebar">
	                <?php include_once('includes/sidebar.php'); ?>
	            </div>
	            <div class="pageContent">
	                <h2>Appointment Form</h2>
	                <div id="calendar"></div>
	            </div>

			</div>
		</div>
		<div class="addAppointmentFOrmWrap" id="add-appointment" title="Add a new appointment">
                    <form name="appfrm"method="POST" action="<?php $base_url;?>add_events.php">
			<h3>Insert New Appointment</h3>
			<!input type="hidden" id="start-date" name="start-date" value="" />
			<input type="hidden" id="end-date" name="end-date" value="" />
			<input type="hidden" id="all-day" name="all-day" value="" />
			<div class="formRow">
				<div class="formLabel">
					<label for="client-id">Client ID</label>
				</div>
				<div class="formValue">
					<input required id="client-id" type="text"  name="client_id" />
				</div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					<label for="vehicle-number">Vehicle Number</label>
				</div>
				<div class="formValue">
					<input required id="vehicle-number" type="text" name="veh_num" />
				</div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					<label for="service-request">Service Request</label>
				</div>
				<div  class="formValue">
                                    
                                    <select  required id="service_request"  name="service_req">
                                       <option value="zero"></option>            
                                       <option value="mechanic">Mechanic</option>
                                       <option value="electrical">Electrical</option>
                                       <option value="wheel_balancing">Wheel Replacing & Balancing</option>
                                       <option value="Complete">Diagnostic</option>
                                       <option value="quotation">Quotation</option>
                                      </select>
                                    
					
				</div>
			</div>
                        <div class="formRow">
				<div class="formLabel">
					<label for="team">Detail:</label>
				</div>
				<div class="formValue">
					
                                        
                                     
                                        <textarea rows="4" cols="40"  type="text" id="infor"   name="infor"   >

                                       </textarea> 
				</div>
                            
                            
                            
                            <div class="formRow">
				<div class="formLabel">
					<label for="Start-date">Start</label>
				</div>
				<div class="formValue">
                                    <input  required id="start-date"  type="text" id="start-date" name="start-date" value="" />
				</div>
			</div>
                            
			</div>
			<div class="formButton">
				<button type="Submit" value="Save" id="btnsave2" name="btnsave2">Save</button>
                                
			</div>
		  </form>
		</div>
	    <?php include_once('includes/footer.php'); ?>
		
		<?php if(!empty($_GET) && !empty($_GET['t'])) : ?>
			<script>
				alert("<?php echo ($_GET['t'] == 1) ? 'Event saved succesfully' : 'Save failed';?>");
			</script>
		<?php endif; ?>
	</body>
</html>
