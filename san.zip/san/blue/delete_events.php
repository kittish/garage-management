﻿<?php

 $app_id=$_POST['app_id'];
If (isset($_POST['app_id']))
    
{


// connexion à la base de données
 try {
 $bdd = new PDO('mysql:host=localhost;dbname=garage_dob', 'root', '');
 } catch(Exception $e) {
 exit('Impossible de se connecter à la base de données.');
 }

$sql = "DELETE from app_tbl WHERE app_id=$app_id";
$q = $bdd->prepare($sql);
$q->execute(array(':app_id' => $_POST['app_id']));
}

print_r($q);