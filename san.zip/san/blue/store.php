<!DOCTYPE HTML>
<?php
// Include the connection of database
include_once 'dbconfig.php';

$currentPage = 'store';

if(!$user->is_loggedin())
{
	$user->redirect('index.php');
}
      //slogin() ;
$uname = $_SESSION['user_session'];

$stmt = $DB_con->prepare("SELECT * FROM login_tbl WHERE uname=:uname");
$stmt->execute(array(":uname"=>$uname));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC)

?> <?php
         if(isset($_post['emp_id']))
        
    {$up="select * from emp_tbl where emp_id=".$_post['emp_id'];
 
     $rst=mysql_query($up);
    $fetched_row=  mysql_fetch_array($rst);}
     
     ?>

<html>

<head>
  <title>CDD Service</title>
  
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
 
 <link rel="stylesheet" href="style/style.css" type="text/css" title="style" />

</head>

<body>
    <div id="main">
        <?php include_once('includes/header.php'); ?>
        <div id="site_content">
            <div class="sidebar">
                <?php include_once('includes/sidebar.php'); ?>
            </div>
            <div class="pageContent">
        <?php 
    
    
        
           $prod_id="";
           $prod_name="";
		   $ref="";
           $prod_price ="";  
           $quantity = "";
           $date_rec = "";
          
          
       
           
            $err2="";
            $err3="";
			$err1="";
           $err4="";
           $err5="";
           $err6="";
        
       
       
        if(isset($_POST['btnsavestore']))
       {
   
         
       
           
          
            $prod_id=trim($_POST['txtprod_id']);
			$prod_name=trim($_POST['txtprod_name']);
		    $ref = trim($_POST['txtref']);
            $prod_price = trim($_POST['txtprod_price']);
            $quantity = trim($_POST['txtquantity']);
            $date_rec = trim($_POST['txtdate_rec']);
          
         
          /* 
           
           $err1=$err2=$err3=$err4=$err5=$err6=$err7="";
		    
		   $txtprod_name=$txtref=$txtprod_price=$txtquantity=$txtdate_rec="";
		   
		   
		   if($_SERVER["REQUEST_METHOD"] =="POST")
		   {
			   
			   
			   if(empty($txtprod_name))
			   {$err1="Input product name....";}
		       
			   else 
			   {$txtprod_name=trim($_POST['txtprod_name']);}
			   
			   
			   if(empty($txtref))
				   $err2="Input referernce";
			   else{$txtref = trim($_POST['txtref']);}
			   
			   if(empty($txtprod_price))
			   {$err3=" Input Price";}
		       else
			   {  $txtprod_price = trim($_POST['txtprod_price']);}
		       
			   if(empty($txtquantity))
			   {$err4="Input Number of Product";}
		       
			    else
				{$txtquantity = trim($_POST['txtquantity']);}
			
			
			    if(empty($txtdate_rec))
				{$err5="Input date of Register";}
			else
			   {$txtquantity = trim($_POST['txtquantity']);}
			   
		   }*/
           
           
//////////////////////////////////////////////////////////////////
         if (empty($prod_name))
              
              {
                  $err1="input product name...";
                  
              }
            else if (is_numeric($prod_name))
                
                {
                    $err1="input product name  ";
                    
                }  
				
				else if (empty($ref))
				{$err2="Please input Reference of Material";}
			
                
                else if (empty($prod_price))
                {
                    $err3 ="Input Product Price";
                    
                }
                
                 else if (!is_numeric( $prod_price))
                     
                     {$err3=" Input numerical value...   "; }
                         
                         
                         
                    
                     
                     
                     else if (empty($quantity))
                {
                    $err4 ="Input Quantity of product...";
                    
                }
                
                 else if (!is_numeric($quantity))
                     
                     
                       {  $err4=" Input numerical value for quantity..";}
                  
                     
                     else if(empty($date_rec)) 
                   
                   {
                       $err5="Please enter the correct date: YY-MM-DD";
                   }
                  
              ///////////////////////////////////////////////
              else if(!preg_match("/^([0-9]{4})-([0-1][0-2])-([0-3][0-9])$/", $date_rec))
                  
                  
                 
                 {$err5=" The format date is incorrect....";}
                 
                 
                     
                  
             
                 
                 else
           
      
                
            
      
 
      
       
         try { 
    
         
           
       
         
         
              $stmt = $DB_con->prepare("INSERT INTO store_tbl
              (prod_id,prod_name,ref,prod_price,quantity,date_rec)
              VALUES('$prod_id','$prod_name','$ref','$prod_price','$quantity','$date_rec')");

              $stmt->bindparam(':$txtprod_name', $prod_name);
			  $stmt->bindparam(':$txtref', $ref);
              $stmt->bindparam(':$txtprod_price', $prod_price);
              $stmt->bindparam(':$txtquantity', $quantity);
              $stmt->bindparam(':$txtdate_rec', $date_rec);
             
              

              $stmt->execute(); 
            
               echo" execute command work  store";     
               return $stmt;
            
              
           }
                catch(PDOException $e)
               {
                echo $e->getMessage();
               }

	       
                
        }
           
    
	if(isset($_POST['btnstoredsearch']))
          {        
              
         
            
            $prod_id=$_POST['txtprod_id'];
		
			$prod_name=$_POST['txtprod_name'];
		    $ref = $_POST['txtref'];
            $prod_price = $_POST['txtprod_price'];
            $quantity = $_POST['txtquantity'];
            $date_rec = $_POST['txtdate_rec'];
             
             echo"search ok";
            
           try {

                   

                {
               
               
                                      
            $r = $DB_con->query("SELECT * FROM store_tbl WHERE prod_id = ".$DB_con->quote($prod_id));
    
            $r->execute();
            $result = $r->setFetchMode(PDO::FETCH_ASSOC);
      
     } 
      
    
           foreach($r as $row)
     
            {   
                  
           $prod_id =$row['prod_id'];
           $prod_name= $row['prod_name'];
		   $ref=$row['ref'];
           $prod_price = $row['prod_price'];
           $quantity=$row['quantity'];
           $date_rec = $row['date_rec'];
           
             }    
         
     }
           catch(PDOException $e)
           {echo "Error occurs:". $e->getMessage();}
                            
          }  



		  if(isset($_POST['btnupdatestore']))
       try
        { 
       
            $prod_id=$_POST['txtprod_id'];
		
			$prod_name=$_POST['txtprod_name'];
		    $ref = $_POST['txtref'];
            $prod_price = $_POST['txtprod_price'];
            $quantity = $_POST['txtquantity'];
            $date_rec = $_POST['txtdate_rec'];
 
       

 
 $pd = "UPDATE store_tbl SET prod_name='$prod_name', ref='$ref', prod_price ='$prod_price',quantity ='$quantity',
date_rec='$date_rec',WHERE prod_id=$prod_id";
 

    //Prepare statement
	
    $stmtup = $DB_con->prepare($pd);

    // execute the query
	
    $stmtup->execute();
    
    
    }
     catch(PDOException $e)
    {//   
    echo $pd . "<br>" . $e->getMessage();
    }
		           
       ?>     

 <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
         
            <table align="center" border="4" cellspacing="5" cellpadding="15" width="100%">
                
                <tbody>
                    
                    
                    <tr>
                    
                        <td colspan="2"  align="center"><font size="18">Store Form</font></td> 
                    </tr>
                               
                    <tr>
                        <td width="30%"   align="right">Product ID:</td>
                         
                         
                         <td width="55%" align="left"><input align="center" type="text" placeholder="Product ID " id="Product_id" name="txtprod_id" value=<?php if(!(empty($prod_id))){echo $prod_id;}else {echo "";}?> >
                                                     <span> <input type="submit" value="Search By ID" name="btnstoredsearch" class="submit"></span></td>
                       
                    </tr>
                    
                    <tr>
                    
                       <td colspan="2" align="center"></td> 
                    </tr>
                              
                    
                     
                    <tr>
                         <td width="30%"  align="right">Product Name:</td>
                        
                         
                         <td width="70%" align="left"><input align="center" type="text" placeholder="Product Name.."  id="prod_name" name="txtprod_name" value=<?php if (!(empty($prod_name))) {echo htmlspecialchars($prod_name);} else {echo "";}  ?> ><span><?php echo $err1;?></span></input></td>
                    </tr>
					
					 <tr>
                         <td width="30%"   align="left">Reference :</td>
                         <td width="70%" align="left"><input type="text"  placeholder="Product Reference" id="ref" name="txtref" value=<?php echo htmlspecialchars($ref);?>><span><?php echo $err2;?></span></input></td>
                    </tr>
                   
                    <tr>
                         <td width="30%"   align="right">Product Price (Rs):</td>
                        <td width="70%" align="left"><input type="text" placeholder="Price Of Product" id="prod_price" name="txtprod_price" value=<?php if (!(empty($prod_price))){echo htmlspecialchars($prod_price);} else {echo"";}  ?>><span><?php echo $err3;?></span></input>
                </td>
                    </tr>
                  
                    <tr>
                         <td width="30%"   align="right">Quantity :</td>
                         <td width="70%" align="left"><input type="text" placeholder="No of Product" id="quantity" name="txtquantity" value=<?php echo $quantity;  ?> ><span><?php echo $err4;?></span></input>
                   </tr>
                    
                   
                    
                    <tr>
                         <td width="30%"   align="left">Date Of Record :</td>
                         <td width="70%" align="left"><input type="text"  placeholder="YY-MM-DD" id="date_rec" name="txtdate_rec" value=<?php echo $date_rec;  ?>><span><?php echo $err5;?></span></input></td>
                    </tr>
                
                    
                        
                        
                        <td colspan="2" align="center"><input type="Submit" value="Save" name="btnsavestore" class="submit"> 
                                               
                                            <input type="submit" value="reset" name="btnresets" class="submit">
                                           
                             </td>
                    </tr>
                    <tr>
                    
                        <td colspan="2" align="center">
                                &nbsp; &nbsp;<input type="Submit" value="Update" name="btnupdatestore" class="submit">
                                    &nbsp; &nbsp;<input type="Submit" value="Delete" name="btndeletes" class="submit">&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;</td>
									
                    </tr>
                    <tr> <td><a href="despatch.php">Despatch Form</a> </td><tr> <td><a href="storereport.php">Store Report</a> </td></tr></tr>
                </tbody>
            </table>
        </form>
            </div>           
        </div>
    </div>

    <?php include_once('includes/footer.php'); ?>
</body>
</html>
